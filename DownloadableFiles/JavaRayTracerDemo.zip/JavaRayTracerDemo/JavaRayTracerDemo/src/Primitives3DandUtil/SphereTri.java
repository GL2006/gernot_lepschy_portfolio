package Primitives3DandUtil;

import Objects3D.Sphere;

public class SphereTri extends Triangle {
    private Vector3 origin;
    private float radius;
    private Sphere ownSphere;
    public SphereTri(Vector3 origin, double radius, Sphere s){
        super(new Vector3[]{origin,origin,origin});
        this.origin = origin;
        this.ownSphere = s;
        this.radius = (float)radius;
    }
    public Vector3 getRayImpactPoint(Vector3 rayOrigin, Vector3 rayDirection){
        double dist = rayIntersect(rayOrigin, rayDirection, 30);
        return dist>0?rayOrigin.add(rayDirection.multiply(dist)):null;
    }
  /*   public double getImpactDistance(Vector3 rayOrigin, Vector3 rayDirection){
        return rayIntersect(rayOrigin, rayDirection, 30);
    }*/
    @Override
    public float getImpactDistance(Vector3 rayOrigin, Vector3 rayDirection) {
        return rayIntersect(rayOrigin, rayDirection, 1/0f);
    }
    public float rayIntersect(Vector3 rayOrigin, Vector3 dir, double maxDist){
        Vector3 oc = rayOrigin.subtract(this.origin);
        //wegen scheiss floating point prec
        float a = Vector3.dot(dir,dir);
        float b = 2.0f * Vector3.dot(oc,dir);
        float c = Vector3.dot(oc,oc) - radius*radius;
        float disc = b*b - 4*a*c;

        if (disc < -1e-10) return -1;
        if(disc < 1e-10) disc = 0;
        float sqrtDisc = (float)Math.sqrt(disc);
        float t1 = (-b - sqrtDisc) / (2.0f * a);
        float t2 = (-b + sqrtDisc) / (2.0f * a);
        float t = -1;
        if (t1 > 1e-6 && t1 < maxDist) t = t1;
        if (t2 > 1e-6 && t2 < maxDist) t = (t < 0 || t2 < t) ? t2 : t;
        return t;
    }
    public Vector3 getNormal(){
        throw new UnsupportedOperationException("Use getNormalAt for spheres!");
    }
    @Override
    public Vector3 getNormalAt(Vector3 impact, Vector3 rayDir) {
        Vector3 n = impact.subtract(origin).normalized();
        if (Vector3.dot(n, rayDir) > 0) n = n.inverted();
        return n;
    }
    public Sphere getOwnerS(){return ownSphere;}
}
