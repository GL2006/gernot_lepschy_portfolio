package Objects3D;

import Primitives3DandUtil.*;
import SceneObjects.Camera;

public class Sphere extends Object3D{
    private double radius;
    public Sphere(Vector3 origin, double radius){
        super(origin);
        this.radius = radius;
        fixBounds();
    }
    //no rotatemethod cause it's a sphere, it doesnt change when rotated
    private void fixBounds(){
        double Ox = origin.getX();
        double Oy = origin.getY();
        double Oz = origin.getZ();
        Vector3 min = new Vector3(Ox-radius, Oy-radius, Oz-radius),
                max = new Vector3(Ox+radius, Oy+radius, Oz+radius);
        super.boundingBox = new AABB(min, max);
    }
    public void move(Vector3 newPos){
        this.origin = newPos;
        fixBounds();
        Camera.recacheObj = this;
    }
    public Triangle[] getTris(){
        SphereTri sphereTri = new SphereTri(origin, radius, this);
        sphereTri.setOwner(this);
        return new Triangle[]{sphereTri};
    }
    public double getRadius(){return radius;}
    public int numberOfTris() {
        return 1;
    }
}
