package InOut;

import java.util.Scanner;

public class In {
    //stripped down
    
    public static String readLine(){
        return read();
    }
    public static char readChar(){ //returns first char in input
        String pre = " " + read();
        if(pre == null){
            return ' ';
        }
        if(string2CharArr(pre).length < 2){
            return ' ';
        }
        return string2CharArr(pre)[1];
    }
    public static int readInt(){
        String pre = read();
        char[] cs = string2CharArr(pre);
        //check how many without illegal
        int counter = 0;
        for (int i = 0; i < cs.length; i++) {
            if(isNumber(cs[i])){
                counter++;
            }
        }
        if(counter == 0){
            return -1;
        }
        String toInt = "";
        for (int i = 0; i < cs.length; i++) {
            if(isNumber(cs[i])){
                toInt += cs[i];
            }
        }
        int numb = Integer.parseInt(toInt);;
        return numb;
    }
    private static boolean isNumber(char cArray){
        return (cArray-'0' >= 0) && (cArray-'0'<=9);
    }
    private static char[] string2CharArr(String pre){
        if(pre == null) return null;
        char[] cArray = new char[pre.length()];
        for (int i = 0; i < pre.length(); i++) {
            cArray[i] = pre.charAt(i);
        }
        return cArray;
    }
    private static String read(){
        Scanner s = new Scanner(System.in);
        String str = s.nextLine();
        return str;
    }
}
