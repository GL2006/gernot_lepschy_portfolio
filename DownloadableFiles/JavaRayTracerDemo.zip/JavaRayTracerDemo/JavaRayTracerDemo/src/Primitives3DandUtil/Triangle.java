package Primitives3DandUtil;

import Objects3D.Object3D;
import Objects3D.Sphere;

public class Triangle {
    public Vector3[] points = new Vector3[3];
    private Vector3 normal;
    private Object3D owner;
   // private float[] cacheVals = new float[6];
    private Vector3 centerV;
    public void setOwner(Object3D o) {
        this.owner = o;
    }

    public Object3D getOwner() {
        return owner;
    }
    public Triangle(Vector3 point1, Vector3 point2, Vector3 point3){
        if(point1==null||point2==null||point3==null) return;
        this.points[0] = point1; this.points[1] = point2; this.points[2] = point3;    
       // CacheVectors();
        computeNormal();
    }
    public Triangle(Vector3[] points){
        if(points==null) return;
        if(points.length != 3) return;
        this.points = points;
       // CacheVectors();
        computeNormal();
    }
    private void computeNormal(){
        Vector3 edge1 = points[1].subtract(points[0]);
        Vector3 edge2 = points[2].subtract(points[0]);
        this.normal = Vector3.cross(edge1, edge2).normalized();
        centerV = points[0].add(points[1]).add(points[2]).multiply(1.0 / 3.0);
    }
    public Vector3 getNormal(){
        return this.normal;
    }
    public Vector3 getCenterV(){
        return centerV;
    }
    public Vector3 getNormalFacing(Vector3 rayDir) {
        if (Vector3.dot(this.normal,rayDir) > 0) {
            return this.normal.inverted();
        }
        return this.normal;
    }
    private void CacheVectors(){
        Vector3 v0 = points[0]; Vector3 v1 = points[1]; Vector3 v2 = points[2]; //cache
        Vector3 edge1 = v1.subtract(v0); Vector3 edge2 = v2.subtract(v0);
        //cacheVals = new float[] {(float)edge1.getX(), (float)edge1.getY(), (float)edge1.getZ(), 
         //   (float)edge2.getX(), (float)edge2.getY(), (float)edge2.getZ()};
    }
    public String toString(){
        String str = "";
        for (int i = 0; i < points.length; i++) {
            str += points[i].toString() + "\n";
        }
        return str;
    }
    public Vector3 getRayImpactPoint(Vector3 rayOrigin, Vector3 rayDirection){
        float dist = getImpactDistance(rayOrigin, rayDirection);
        return dist > 0? Vector3.plus(rayOrigin, Vector3.mult(rayDirection, dist)):null;
        //rayDirection.normalizeFloat();
        /*final float EPSILON = 1e-6f; //praezision
        Vector3 v0 = points[0]; Vector3 v1 = points[1]; Vector3 v2 = points[2]; //cache

        Vector3 edge1 = v1.subtract(v0); Vector3 edge2 = v2.subtract(v0);
        Vector3 h = Vector3.cross(rayDirection,edge2);
        float a = Vector3.dot(edge1,h);
        if (a > -EPSILON && a < EPSILON) return null; //paralell
        
        float f = 1.0f/a;
        Vector3 s = rayOrigin.subtract(v0);
        float u = f * Vector3.dot(s,h);
        if (u < -EPSILON || u > 1.0f + EPSILON) return null;
        
        Vector3 q = Vector3.cross(s,edge1);
        float v = f * Vector3.dot(rayDirection,q);
        
        if (v < -EPSILON || u + v > 1.0f + EPSILON) return null;
        float t = f * Vector3.dot(edge2,q);

        if (t >= 0) return rayOrigin.add(rayDirection.multiply(t)); //Schnittpunkt
        return null;*/
    }
    public float getImpactDistance(Vector3 rayOrigin, Vector3 rayDirection){
        if (Vector3.dot(normal, rayDirection) > 0) return -1;
        float[] result = new float[3];
        if (Vector3.intersectTriangle(rayOrigin, rayDirection, points[0], points[1], points[2], result)) {
            return result[0];
        }
        return -1;
      /*  final double EPSILON = 1e-4f; //praezision
        Vector3 v0 = points[0]; Vector3 v1 = points[1]; Vector3 v2 = points[2]; //cache

        Vector3 edge1 = v1.subtract(v0); Vector3 edge2 = v2.subtract(v0);
        Vector3 h = Vector3.cross(rayDirection, edge2);
        double a = Vector3.dot(edge1,h);
        if (Math.abs(a) < EPSILON) return -1f; //paralell
        
        double f = 1.0/a;
        Vector3 s = rayOrigin.subtract(v0);
        double u = f * Vector3.dot(s,h);
        if (u < 0.0f) return -1f;
        
        Vector3 q = Vector3.cross(s, edge1);
        double v = f * Vector3.dot(rayDirection,q);
        if(v < 0.0f) return -1f;
        if (u + v > 1.0f) return -1f;
        double t = f * Vector3.dot(edge2,q); //((cacheVals[3]*(float)q.getX()+cacheVals[4]*(float)q.getY()+cacheVals[5])*(float)q.getZ());

        return (t >= EPSILON)? t:-1; //Schnittpunkt*/
    }
    public Vector3 getNormalAt(Vector3 impact, Vector3 rayDir) {
        return Vector3.dot(normal,rayDir) > 0 ? normal.inverted():normal;
    }
    public boolean isReflective() {
        return owner.isReflective();
    }
    public Sphere getOwnerS(){return null;}
}
