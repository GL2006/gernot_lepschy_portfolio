package Support;

import java.util.Scanner;

public class In {
    //stripped down
    
    public static String readLine(){
        return read();
    }
    public static char readChar(){ //returns first char in input
        String pre = " " + read();
        if(pre == null){
            return ' ';
        }
        if(string2CharArr(pre).length < 2){
            return ' ';
        }
        return string2CharArr(pre)[1];
    }
    public static double readDouble(){
        String pre = read();
        char[] cs = string2CharArr(pre);
        int dotIndex = -1;
        for (int i = 0; i < cs.length; i++) {
            if (cs[i] == '.' || cs[i] == ',') {
                dotIndex = i;
                break;
            }
        }
        if(dotIndex == -1){
            int counter = 0;
            for (int i = 0; i < cs.length; i++) {
                if(isNumber(cs[i])){
                    counter++;
                }
            }
            if(counter == 0){
                return -1;
            }
            String toInt = "";
            for (int i = 0; i < cs.length; i++) {
                if(isNumber(cs[i])){
                    toInt += cs[i];
                }
            }
            int numb = Integer.parseInt(toInt);;
            return numb;
        }else{
            String toInt = "";
            for (int i = 0; i < dotIndex; i++) {
                if(isNumber(cs[i])){
                    toInt += cs[i];
                }
            }
            int numb1 = toInt.isEmpty() ? 0 : Integer.parseInt(toInt);
            //after comma then!
            String afterComma = "";
            for (int i = dotIndex; i < cs.length && afterComma.length() < 3; i++) {
                if(isNumber(cs[i])){
                    afterComma += cs[i];
                }
            }
            //then only make it 3 places!
            char[] cs2 = string2CharArr(afterComma);
            String c2 = "";
            for (int i = 0; i < cs2.length; i++) {
                if(i < 3){
                    c2 += cs2[i];
                }
            }
            while (c2.length() < 3) {
                c2 += "0";
            }
            int numb2 = Integer.parseInt(c2);
            double d = (double)numb1 +(double)numb2 / 1000.0;
            return d;
        }
    }
    public static int readInt(){
        String pre = read();
        char[] cs = string2CharArr(pre);
        //check how many without illegal
        int counter = 0;
        for (int i = 0; i < cs.length; i++) {
            if(isNumber(cs[i])){
                counter++;
            }
        }
        if(counter == 0){
            return -1;
        }
        String toInt = "";
        for (int i = 0; i < cs.length; i++) {
            if(isNumber(cs[i])){
                toInt += cs[i];
            }
        }
        int numb = Integer.parseInt(toInt);;
        return numb;
    }
    private static boolean isNumber(char cArray){
        return (cArray-'0' >= 0) && (cArray-'0'<=9);
    }
    private static char[] string2CharArr(String pre){
        if(pre == null) return null;
        char[] cArray = new char[pre.length()];
        for (int i = 0; i < pre.length(); i++) {
            cArray[i] = pre.charAt(i);
        }
        return cArray;
    }
    private static String read(){
        Scanner s = new Scanner(System.in);
        String str = s.nextLine();
        return str;
    }
}

