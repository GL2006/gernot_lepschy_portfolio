package Primitives3DandUtil;

import Objects3D.Object3D;

public class Hit {
    public Vector3 pos;
    public double dist;
    public Triangle tri;
    public final Color color;
    public Object3D owner;

    public Hit(Vector3 pos, double dist, Triangle tri, Color color, Object3D owner) {
        this.pos = pos;
        this.dist = dist;
        this.tri = tri;
        this.color = color;
        this.owner = owner;
    }
    public Hit(Triangle tri, Vector3 pos, double dist, Color color, Object3D owner) {
        this.pos = pos;
        this.dist = dist;
        this.tri = tri;
        this.color = color;
        this.owner = owner;
    }
    public Vector3 point(){
        return pos;
    }
}
