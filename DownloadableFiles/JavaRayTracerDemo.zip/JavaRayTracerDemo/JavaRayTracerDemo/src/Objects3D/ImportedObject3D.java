package Objects3D;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import Primitives3DandUtil.*;
import SceneObjects.Camera;

public class ImportedObject3D extends Object3D{
    private List <Triangle> triangles;
    private List <Vector3> vertices;
    private List <Vector3> normals;
    private List <Vector3[]> textureCoords; //keine texturen aber joa, ist halt in .obj so

    public ImportedObject3D(Vector3 origin, String objFilePath) {
        super(origin);
        this.triangles = new ArrayList<>();
        this.vertices = new ArrayList<>();
        this.normals = new ArrayList<>();
        this.textureCoords = new ArrayList<>();
        loadOBJ(objFilePath);
        buildBoundingBox();
    }
    public ImportedObject3D(Vector3 origin, String objFilePath, Color color) {
        super(origin);
        super.setColor(color);
        this.triangles = new ArrayList<>();
        this.vertices = new ArrayList<>();
        this.normals = new ArrayList<>();
        this.textureCoords = new ArrayList<>();
        loadOBJ(objFilePath);
        buildBoundingBox();
    }
    public void RotX(int amount){
        Vector3 c = getCenter();
        double a = Math.toRadians(amount);
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        for (Triangle t : triangles) {
            for (int i = 0; i < 3; i++) {
                Vector3 v = t.points[i].subtract(c);
                double y = v.getY() * cos - v.getZ() * sin;
                double z = v.getY() * sin + v.getZ() * cos;
                t.points[i] = new Vector3(v.getX(), y, z).add(c);
            }
        }
        buildBoundingBox();
        Camera.recacheObj = this;
    }
    public void RotY(int amount){
        Vector3 c = getCenter();
        double a = Math.toRadians(amount);
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        for (Triangle t : triangles) {
            for (int i = 0; i < 3; i++) {
                Vector3 v = t.points[i].subtract(c);
                double x =  v.getX() * cos + v.getZ() * sin;
                double z = -v.getX() * sin + v.getZ() * cos;
                t.points[i] = new Vector3(x, v.getY(), z).add(c);
            }
        }
        buildBoundingBox();
        Camera.recacheObj = this;
    }
    public void RotZ(int amount){
        Vector3 c = getCenter();
        double a = Math.toRadians(amount);
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        for (Triangle t : triangles) {
            for (int i = 0; i < 3; i++) {
                Vector3 v = t.points[i].subtract(c);
                double x = v.getX() * cos - v.getY() * sin;
                double y = v.getX() * sin + v.getY() * cos;
                t.points[i] = new Vector3(x, y, v.getZ()).add(c);
            }
        }
        buildBoundingBox();
        Camera.recacheObj = this;
    }
    public Vector3 getCenter(){
        double cx = 0, cy = 0, cz = 0;
        int count = 0;
        for (Triangle t : triangles) {
            for (Vector3 p : t.points) {
                cx += p.getX();
                cy += p.getY();
                cz += p.getZ();
                count++;
            }
        }
        return new Vector3(cx / count, cy / count, cz / count);
    }
    private void loadOBJ(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue; // Kommentare und leere Zeilen überspringen
                }
                
                String[] parts = line.split("\\s+");
                if (parts.length < 2) continue;
                
                switch (parts[0]) {
                    case "v": // Vertex
                        if (parts.length >= 4) {
                            double x = Double.parseDouble(parts[1]);
                            double y = Double.parseDouble(parts[2]);
                            double z = Double.parseDouble(parts[3]);
                            vertices.add(new Vector3(x, y, z));
                        }
                        break;
                        
                    case "vn": // Vertex Normal
                        if (parts.length >= 4) {
                            double nx = Double.parseDouble(parts[1]);
                            double ny = Double.parseDouble(parts[2]);
                            double nz = Double.parseDouble(parts[3]);
                            normals.add(new Vector3(nx, ny, nz));
                        }
                        break;
                        
                    case "vt": // Texture Coordinate
                        if (parts.length >= 3) {
                            double u = Double.parseDouble(parts[1]);
                            double v = Double.parseDouble(parts[2]);
                            // Hier speichern wir UV-Koordinaten (können später für Texturen verwendet werden)
                            textureCoords.add(new Vector3[] {new Vector3(u, v, 0)});
                        }
                        break;
                        
                    case "f": // Face (Polygon)
                        processFace(parts);
                        break;
                }
            }
            
            System.out.println("Loaded .obj: " + vertices.size() + " vertices, " + triangles.size() + " triangles");
            
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error loading .obj file: " + e.getMessage());
            // Fallback: Erstelle einen einfachen Würfel
            createFallbackCube();
        }
    }

    private void processFace(String[] parts) {
        // OBJ-Faces können Dreiecke, Vierecke oder n-Ecke sein
        // Wir unterstützen nur Dreiecke und Vierecke (werden in Dreiecke zerlegt)
        
        if (parts.length < 4) return; // Mindestens 3 Punkte für ein Dreieck
        
        List<Integer> vertexIndices = new ArrayList<>();
        List<Integer> normalIndices = new ArrayList<>();
        List<Integer> texIndices = new ArrayList<>();
        
        // Parse jede Vertex-Referenz (kann sein: v, v/vt, v//vn, v/vt/vn)
        for (int i = 1; i < parts.length; i++) {
            String[] indices = parts[i].split("/");
            
            // Vertex Index (immer vorhanden)
            if (indices.length > 0 && !indices[0].isEmpty()) {
                int vIdx = Integer.parseInt(indices[0]);
                // OBJ-Indizes sind 1-basiert, negative Werte sind relativ
                if (vIdx < 0) {
                    vIdx = vertices.size() + vIdx + 1;
                }
                vertexIndices.add(vIdx - 1); // Auf 0-basiert umrechnen
            }
            
            // Texture Index (optional)
            if (indices.length > 1 && !indices[1].isEmpty()) {
                int tIdx = Integer.parseInt(indices[1]);
                if (tIdx < 0) {
                    tIdx = textureCoords.size() + tIdx + 1;
                }
                texIndices.add(tIdx - 1);
            }
            
            // Normal Index (optional)
            if (indices.length > 2 && !indices[2].isEmpty()) {
                int nIdx = Integer.parseInt(indices[2]);
                if (nIdx < 0) {
                    nIdx = normals.size() + nIdx + 1;
                }
                normalIndices.add(nIdx - 1);
            }
        }
        
        // Polygon triangulieren (nur Dreiecke und Vierecke unterstützt)
        if (vertexIndices.size() == 3) {
            // Einfaches Dreieck
            createTriangleFromIndices(vertexIndices, normalIndices);
        } else if (vertexIndices.size() == 4) {
            // Viereck in zwei Dreiecke zerlegen
            // Dreieck 1: v0, v1, v2
            createTriangleFromIndices(
                Arrays.asList(vertexIndices.get(0), vertexIndices.get(1), vertexIndices.get(2)),
                normalIndices.size() >= 3 ? 
                    Arrays.asList(normalIndices.get(0), normalIndices.get(1), normalIndices.get(2)) : 
                    new ArrayList<>()
            );
            // Dreieck 2: v0, v2, v3
            createTriangleFromIndices(
                Arrays.asList(vertexIndices.get(0), vertexIndices.get(2), vertexIndices.get(3)),
                normalIndices.size() >= 4 ?
                    Arrays.asList(normalIndices.get(0), normalIndices.get(2), normalIndices.get(3)) :
                    new ArrayList<>()
            );
        }
        // Größere Polygone werden ignoriert (können erweitert werden)
    }

    private void createTriangleFromIndices(List<Integer> vertexIndices, List<Integer> normalIndices) {
        if (vertexIndices.size() != 3) return;
        
        Vector3[] triVertices = new Vector3[3];
        Vector3[] triNormals = new Vector3[3];
        
        // Hole Vertices (mit Offset zum Ursprung)
        for (int i = 0; i < 3; i++) {
            int idx = vertexIndices.get(i);
            if (idx >= 0 && idx < vertices.size()) {
                triVertices[i] = vertices.get(idx).add(origin); // Offset zum Objekt-Ursprung
            } else {
                return; // Ungültiger Index
            }
        }
        
        // Erstelle Triangle mit oder ohne Normals
        Triangle triangle = new Triangle(triVertices);
        triangle.setOwner(this);
        
        // Wenn Normals vorhanden sind, überschreibe die berechnete Normal
        if (normalIndices.size() == 3) {
            // Hier könntest du benutzerdefinierte Normals setzen
            // (würde eine Erweiterung der Triangle-Klasse benötigen)
        }
        
        triangles.add(triangle);
    }
    
    private void createFallbackCube() {
        // Fallback: Erstelle einen einfachen Würfel
        Cube fallbackCube = new Cube(origin, 1, 1, 1);
        Triangle[] cubeTris = fallbackCube.getTris();
        for (Triangle tri : cubeTris) {
            tri.setOwner(this);
            triangles.add(tri);
        }
    }
    
    private void buildBoundingBox() {
        if (triangles.isEmpty()) {
            boundingBox = new AABB(origin, origin);
            return;
        }
        
        double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
        
        for (Triangle tri : triangles) {
            for (Vector3 vertex : tri.points) {
                minX = Math.min(minX, vertex.getX());
                minY = Math.min(minY, vertex.getY());
                minZ = Math.min(minZ, vertex.getZ());
                maxX = Math.max(maxX, vertex.getX());
                maxY = Math.max(maxY, vertex.getY());
                maxZ = Math.max(maxZ, vertex.getZ());
            }
        }
        
        boundingBox = new AABB(new Vector3(minX, minY, minZ), new Vector3(maxX, maxY, maxZ));
    }
    
    @Override
    public Triangle[] getTris() {
        return triangles.toArray(new Triangle[0]);
    }
    
    @Override
    public int numberOfTris() {
        return triangles.size();
    }
    // Hilfsmethode zur Skalierung des importierten Objekts
    public void scale(double scaleFactor) {
        for (Triangle tri : triangles) {
            for (int i = 0; i < 3; i++) {
                // Skaliere relativ zum Ursprung
                Vector3 relative = tri.points[i].subtract(origin);
                Vector3 scaled = relative.multiply(scaleFactor);
                tri.points[i] = origin.add(scaled);
            }
            // Normal neu berechnen
            Vector3 edge1 = tri.points[1].subtract(tri.points[0]);
            Vector3 edge2 = tri.points[2].subtract(tri.points[0]);
            // (In einer echten Implementierung würde man die Normals neu berechnen)
        }
        buildBoundingBox();
    }
}
