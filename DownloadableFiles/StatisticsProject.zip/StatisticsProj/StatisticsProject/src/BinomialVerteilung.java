public class BinomialVerteilung {
    private int n;
    private double p;
    static String ANSI_RES = "\u001B[0m", ANSI_RED = "\u001B[31m";
    public static boolean colorInput = true;
    static int resH = -1, resW = -1;
    public BinomialVerteilung(int n, double p){
        this.n = n;
        this.p = p>0?p<1?p:p/100:0;
    }
    public static void setRes(int w, int h){
        resH = h; resW = w;
    }
    public static void setColor(boolean color){
        ANSI_RES = color?"\u001B[0m":"";
        ANSI_RED =color?"\u001B[31m":"";
    }
    public int getN(){
        return n;
    }
    public double getP(){
        return p;
    }
    public double dichte(int k){
        if (k < 0 || k > n) return 0.0;
        //P(X=k)
        //n über k mal p^k * (1-p)^n-k
        /*double bin = (double)binomial(n, k);
        double secondComp01 = Math.pow(p, k);
        double secondComp02 = Math.pow((1-p),(n-k));
        return bin * secondComp01 * secondComp02;*/
        double result = 1.0;
        for (int i = 1; i <= k; i++) {
            result *= (double)(n - k + i) / i;
        }
        return result * Math.pow(p, k) * Math.pow(1 - p, n - k);
    }
    public String invPxPrint(double p){
        double my2 = (double)n * p;
        double sd2 = my2 * (1-p);
        sd2 = Math.sqrt(sd2);
        NormalVerteilung tempNv = new NormalVerteilung(my2, sd2);
        int inv = (int)(tempNv.invertPx(p));
        String str = "P(X<" + ANSI_RED + "k" + ANSI_RES + ") = " + p +" = "+ round3(p*100) + "% --> "+ANSI_RED +"x"+ANSI_RES +" = " + inv;
        str += "\n";
        str += toStringWPara(120, 20, inv, true, false);
        str += "\n" + "P(X<" + ANSI_RED + "k" + ANSI_RES + ") = " + p +" = "+ round3(p*100) + "% --> "+ANSI_RED +"x"+ANSI_RES +" = " + inv;
        return str;
    }
    private long binomial(int n, int k)
    {
        if (k>n-k)
            k=n-k;

        long b=1;
        for (int i=1, m=n; i<=k; i++, m--)
            b=b*m/i;
        return b;
    }
    public String EqPrint(int k){
        double prob = Peq(k);
        String str = "P(X=" + k + ") = " + prob;
        str += "\n";
        str += toStringWPara(120, 20, -1, false, false);
        str += "\n" +"P(X=" + k + ") = " + prob;
        return str;
    }
    public double Peq(int k){
        return round3(dichte(k));
    }
    public double Pless(int k){
        double prob = 0;
        for (int i = 0; i < k; i++) {
            prob += dichte(i);
        }
        return round3(prob);
    }
    public String PlessPrint(int k){
        double prob = Pless(k);
        String str = "P(X<" + k + ") = " + prob;
        str += "\n";
        str += toStringWPara(120, 20, k, true, false);
        str += "\n" +"P(X<" + k + ") = " + prob;
        return str;
    }
    public double PlessEq(int k){
        return round3(Pless(k+1));
    }
    public String PlessEqPrint(int k){
        double prob = PlessEq(k);
        String str = "P(X<=" + k + ") = " + prob;
        str += "\n";
        str += toStringWPara(120, 20, k+1, true, false);
        str += "\n" +"P(X<=" + k + ") = " + prob;
        return str;
    }
    public String PmorePrint(int k){
        double prob = Pmore(k);
        String str = "P(X>" + k + ") = " + prob;
        str += "\n";
        str += toStringWPara(120, 20, k, true, true);
        str += "\n" + "P(X>" + k + ") = " + prob;
        return str;
    }
    public double Pmore(int k){
        return round3(1 - (PlessEq(k)));
    }
    public String PmoreEqPrint(int k){
        double prob = PmoreEq(k);
        String str = "P(X>=" + k + ") = " + prob;
        str += "\n";
        str += toStringWPara(120, 20, k-1, true, true);
        str += "\n" +"P(X>=" + k + ") = " + prob;
        return str;
    }
    public double PmoreEq(int k){
        return round3(1-(Pless(k)));
    }
    public String PbetwPrint(int a, int b){
        double prob = Pbetw(a, b);
        int temp = a>b?b:a; //kleinere
        a = a == temp?b:a;
        b = b == temp?b:temp;
        String str = "P(" + a + "< X <" + b + ") = " + prob;
        str += "\n";
        str += toStringWBetwen(120, 20, a, b, true, false);
        str += "\n" +"P(" + a + "< X <" + b + ") = " + prob;
        return str;
    }
    public double Pbetw(int a, int b){
        double d = a>b?Pless(a)-Pless(b):Pless(b)-Pless(a);
        return d;
    }
    public String toString(){
        return toStringWPara(120, 20, -1, false, false);
    }
    public String toStringWBetwen(int wIn, int hIn, double x, double y, boolean show, boolean flip){
        int width = resW != -1 ? resW:120;
        int height = resH!= -1 ?resH:20;
        double[] dValues = new double[width];
        //first we get the bounds of the equivalent of z = -3 to z = 3
        // z = (x-my)/sD -> -3 = (?-my)/sD |*sD |+my --> -3*sD + my = x;
        //my ist n * p, SD = n*p*(1-p) 
        double startX = (-3*Math.sqrt(n*p*(1-p))) + n * p;
        startX = startX > 0? startX:0;
        double endX = (3*Math.sqrt(n*p*(1-p))) + n * p;
        endX = endX > startX ?endX: startX+1;
        for (int i = 0; i < dValues.length; i++) {
            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            dValues[i] = dichte((int)Math.round(currX));
        }
        //from -3 to 3, steps of 0.2 --> 30 rows, 10 collums
        //then we get maximum dValue, can only be > 0
        double maxD = -1;
        for (int i = 0; i < dValues.length; i++) {
            if(dValues[i] >= maxD){
                maxD = dValues[i];
            }
        }
        double upperDiagr = round3(maxD);
        double middleDiagr = round3(maxD/2);
        //binary matrix!
        double xCut = show?x:startX-1;
        int[][] bValues = new int[height][width];
        for (int i = 0; i < width; i++) {

            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            int value = currX < xCut && currX > y ? 2 : 1;

            int h = (int) Math.round((dValues[i] / maxD) * (double)(height - 1));
            for (int j = height -1; j >=  height-1-h; j--) {
                bValues[j][i] = value;
            }   
        }
        //now really toString!
        String str = "";
        for (int i = 0; i < bValues.length; i++) {
            if(i == 0){
                str += upperDiagr + "|"; //123_|
            }else{
                if(i == height/2){
                    str += middleDiagr + "|";
                }else{
                    if(i == height-1){
                        str += "0.000" + "|";
                    }
                    else{
                        str += "     |";
                    }
                }
            }
            for (int j = 0; j < bValues[i].length; j++) {
                if(bValues[i][j] == 1){
                    str += flip?(ANSI_RED + "#" + ANSI_RES):("*");
                }else{
                    if(bValues[i][j] == 2){
                        str+=flip?("*"):(ANSI_RED + "#" + ANSI_RES);
                    }else{
                        str+=" ";
                    }
                }
            }
            str+="\n";
        }
        str += "     |";
        for (int i = 0; i <= bValues[0].length; i++) {
            str+="-";
        }
        str += "\n      ";
        //0.000
        str+=round3(startX);
        int lI = 0;
        for (int i = 4; i < bValues[0].length/2-2; i++) {
            str += " ";
            lI = i;
        }
        str +=round3(n*p);
        for (int i = lI+6; i < bValues[0].length-4; i++) {
            str += " ";
        }
        str += round3(endX);
        return str;
    }
    public String toStringWPara(int wIn, int hIn, double x, boolean show, boolean flip){
        int width = resW != -1 ? resW:120;
        int height = resH!= -1 ?resH:20;
        double[] dValues = new double[width];
        //first we get the bounds of the equivalent of z = -3 to z = 3
        // z = (x-my)/sD -> -3 = (?-my)/sD |*sD |+my --> -3*sD + my = x;
        //my ist n * p, SD = n*p*(1-p) 
        double startX = (-3*Math.sqrt(n*p*(1-p))) + n * p;
        startX = startX > 0? startX:0;
        double endX = (3*Math.sqrt(n*p*(1-p))) + n * p;
        endX = endX > startX ?endX: startX+1;
        for (int i = 0; i < dValues.length; i++) {
            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            dValues[i] = dichte((int)Math.round(currX));
        }
        //from -3 to 3, steps of 0.2 --> 30 rows, 10 collums
        //then we get maximum dValue, can only be > 0
        double maxD = -1;
        for (int i = 0; i < dValues.length; i++) {
            if(dValues[i] >= maxD){
                maxD = dValues[i];
            }
        }
        double upperDiagr = round3(maxD);
        double middleDiagr = round3(maxD/2);
        //binary matrix!
        double xCut = show?x:startX-1;
        int[][] bValues = new int[height][width];
        for (int i = 0; i < width; i++) {

            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            int value = currX < xCut ? 2 : 1;

            int h = (int) Math.round((dValues[i] / maxD) * (double)(height - 1));
            for (int j = height -1; j >=  height-1-h; j--) {
                bValues[j][i] = value;
            }   
        }
        //now really toString!
        String str = "";
        for (int i = 0; i < bValues.length; i++) {
            if(i == 0){
                str += upperDiagr + "|"; //123_|
            }else{
                if(i == height/2){
                    str += middleDiagr + "|";
                }else{
                    if(i == height-1){
                        str += "0.000" + "|";
                    }
                    else{
                        str += "     |";
                    }
                }
            }
            for (int j = 0; j < bValues[i].length; j++) {
                if(bValues[i][j] == 1){
                    str += flip?(ANSI_RED + "#" + ANSI_RES):("*");
                }else{
                    if(bValues[i][j] == 2){
                        str+=flip?("*"):(ANSI_RED + "#" + ANSI_RES);
                    }else{
                        str+=" ";
                    }
                }
            }
            str+="\n";
        }
        str += "     |";
        for (int i = 0; i <= bValues[0].length; i++) {
            str+="-";
        }
        str += "\n      ";
        //0.000
        str+=round3(startX);
        int lI = 0;
        for (int i = 4; i < bValues[0].length/2-2; i++) {
            str += " ";
            lI = i;
        }
        str +=round3(n*p);
        for (int i = lI+6; i < bValues[0].length-4; i++) {
            str += " ";
        }
        str += round3(endX);
        return str;
    }
    double round3(double d){
        return Math.round(d * 1000.0)/1000.0;
    }
}
