package SceneObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import InOut.*;
import Objects3D.*;
import Primitives3DandUtil.*;

public class Camera {
    private Vector3 position, direction;
    // private int resX, resY;
    private double[][] dephtMatrix;
    private Color[][] colors;
    // private double currInterSect = -1;
    private Object3D[] object3ds;
    int numberOfOp = 0;
    protected Light[] lights;
    private double rotation = 0;
    private static final char[] SHADES = { '@', '#', '8', '&', '*', ':', '.', ' ' };
    private boolean multithread = true, bhvBOOL = true, raytracebool = true;
    private Triangle[][] cachedTris;
    private Color[] cachedColors;
    private BHVNode bvh;
    private final String numTri;
    public Color skyColor;

    public static Object3D recacheObj = null;
    public static boolean onlyCol = false;
    // für raytracing
    private static final int MAX_DEPTH = 3;
    private static final double EPS = 1e-3;
    public float globalFov = 60;
    private boolean alr = false;
    public double maxDist = 30;
    public float ambient = 0.05f;

    public Camera(Vector3 position, Vector3 direction, Object3D[] object3ds, Light[] lights) {
        recacheObj = null;
        this.skyColor = Color.NEGATIVE();
        this.position = position == null ? new Vector3(0, 0, 0) : position;
        this.lights = lights;
        this.direction = direction == null || direction.length() == 0 ? new Vector3(0, 0, 1) : direction;
        // System.out.println(this.resX + "; " +resY);
        dephtMatrix = new double[10][10];
        this.object3ds = object3ds;
        cachedTris = new Triangle[object3ds.length][];
        cachedColors = new Color[object3ds.length];
        Triangle[] allTris = getAllTris();
        numTri = "Number of Tris: " + allTris.length;
        System.out.println(numTri);
        bvh = BVHBuilder.build(allTris);
        cache();
    }

    private void cache() {
        for (int i = 0; i < object3ds.length; i++) {
            cachedColors[i] = object3ds[i].getColor();
            cachedTris[i] = object3ds[i].getTris();
        }
    }

    public int getIndx(Object3D toRecache) {
        int reCInt = -1;
        // find index of it
        for (int i = 0; i < object3ds.length; i++) {
            reCInt = object3ds[i] == toRecache ? i : reCInt;
        }
        return reCInt;
    }

    public void reCache(int index) {
        System.out.println("RECACHE color");
        for (int i = 0; i < object3ds.length; i++) {
            cachedColors[i] = object3ds[i].getColor();
        }
        if(!onlyCol){
            System.out.println("RECACHE geo");
            cachedTris[index] = object3ds[index].getTris();
            bvh = BVHBuilder.build(getAllTris());
        }
        onlyCol = false;
    }

    public Camera(Vector3 position, Vector3 direction, Object3D[] object3ds, Light[] lights, Color skyColor) {
        TestImage.setSkyColor(skyColor);
        this(position, direction, object3ds, lights);
        this.skyColor = skyColor;
    }

    private char shade(double dist) {
        double max = 20.0;
        int idx = (int) ((dist / max) * (SHADES.length - 1));
        idx = Math.max(0, Math.min(idx, SHADES.length - 1));
        return SHADES[idx];
    }

    public void reset() {
        for (int i = 0; i < dephtMatrix.length; i++) {
            for (int j = 0; j < dephtMatrix[i].length; j++) {
                dephtMatrix[i][j] = -1;
            }
        }
    }

    // create plane
    private void measure(int resX, int resY, boolean colored) {
        // reset();
        if (recacheObj != null) {
            reCache(getIndx(recacheObj));
            recacheObj = null;
        }

        dephtMatrix = new double[resY][resX];
        dephtMatrix = depthImageMeasure(resX, resY, colored);
    }

    public String ASCIIrender(int resX, int resY) {
        long unixTime = System.currentTimeMillis();
        resX = resX <= 0 ? 80 : resX;
        resY = resY <= 0 ? 24 : resY;
        measure(resX, resY, false);
        String str = "";
        System.out.println(dephtMatrix.length + "; " + dephtMatrix[0].length);
        for (int i = 0; i < dephtMatrix.length; i++) {
            for (int j = 0; j < dephtMatrix[i].length; j++) {
                if (dephtMatrix[i][j] < 0) {
                    str += " ";
                } else {
                    str += shade(dephtMatrix[i][j]);
                }
            }
            str += "\n";
        }
        long unixTime2 = System.currentTimeMillis();
        System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
        return str;
    }

    public void DephtImageRender(int resX, int resY) {
        long unixTime = System.currentTimeMillis();
        resX = resX <= 0 ? 80 : resX;
        resY = resY <= 0 ? 24 : resY;
        measure(resX, resY, false);
        TestImage.saveImg(dephtMatrix, maxDist, -1, null, 1, 1);
        long unixTime2 = System.currentTimeMillis();
        System.out.println(numTri);
        System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
    }

    public void SeperatedDephtImageRender(int resX, int resY, int howmany) {
        long unixTime = System.currentTimeMillis();
        resX = resX <= 0 ? 80 : resX;
        resY = resY <= 0 ? 24 : resY;
        measure(resX, resY, false);
        TestImage.seperateDephtImg(dephtMatrix, howmany);
        long unixTime2 = System.currentTimeMillis();
        System.out.println(numTri);
        System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
    }

    public void SeperatedDephtColorImageRender(int resX, int resY, int howmany) {
        long unixTime = System.currentTimeMillis();
        resX = resX <= 0 ? 80 : resX;
        resY = resY <= 0 ? 24 : resY;
        measure(resX, resY, true);
        TestImage.seperateDephtImg(dephtMatrix, howmany, colors);
        long unixTime2 = System.currentTimeMillis();
        System.out.println(numTri);
        System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
    }

    public void ColorImageRender(int resX, int resY, double upscaleFac) {
        long unixTime = System.currentTimeMillis();
        resX = resX <= 0 ? 80 : resX;
        resY = resY <= 0 ? 24 : resY;
        measure(resX, resY, true);
        TestImage.saveImg(dephtMatrix, maxDist, 0, colors, 2, upscaleFac);
        long unixTime2 = System.currentTimeMillis();
        System.out.println(numTri);
        System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
    }

    public void ColorImageRender(int resX, int resY) {
        ColorImageRender(resX, resY, 1);
    }

    public void efficientRender(int resX, int resY, double upscaleFac, int i) {
        TestImage.number = -100;
        int nResX = (int) (resX / upscaleFac);
        int nResY = (int) (resY / upscaleFac);
        double fact0 = (double) resX / (double) nResX;
        double fact1 = (double) resY / (double) nResY;
        double newFact = (fact0 + fact1) / 2;
        System.out.println(
                "x" + resX + "to X:" + nResX + "y" + resY + "to Y" + nResY + "fact" + newFact + "\nimg NR: " + i);
        imageRender(nResX, nResY, newFact, i);
    }

    public void efficientRender(int resX, int resY, double upscaleFac) {
        efficientRender(resX, resY, upscaleFac, 0);
    }

    public void imageRender(int IresX, int IresY, int i) {
        imageRender(IresX, IresY, 1, i);
    }

    public void imageRender(int IresX, int IresY, double fact, int i) {
        TestImage.number = -100;
        long unixTime = System.currentTimeMillis();
        IresX = IresX <= 0 ? 80 : IresX;
        IresY = IresY <= 0 ? 24 : IresY;
        measure(IresX, IresY, true);
        TestImage.saveImg(dephtMatrix, maxDist, i, colors, 2, fact);
        // toImage.saveImg(imageMeasure(IresX, IresY), 30,i, colors);
        long unixTime2 = System.currentTimeMillis();
        if (i < 2)
            System.out.println(numTri);
        if (i < 100)
            System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
    }

    private void drawLine(int x0, int y0, int x1, int y1, int rgb, int resX, int resY, double[][] wire) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int steps = Math.max(dx, dy);
        if (steps == 0) {
            if (x0 >= 0 && y0 >= 0 && x0 < resX && y0 < resY)
                wire[y0][x0] = rgb;
            return;
        }
        for (int i = 0; i <= steps; i++) {
            int x = x0 + (x1 - x0) * i / steps;
            int y = y0 + (y1 - y0) * i / steps;

            if (x >= 0 && y >= 0 && x < resX && y < resY)
                wire[y][x] = rgb;
        }
    }

    public Vector2 project(Vector3 world, int resX, int resY) {
        Vector3 p = world.subtract(position);
        Vector3 lookAt = position.add(direction);
        Vector3 forward = lookAt.subtract(position).normalized();
        Vector3 worldUp = Math.abs(forward.getY()) > 0.99
                ? new Vector3(0, 0, 1)
                : new Vector3(0, 1, 0);
        Vector3 right = forward.cross(worldUp).normalized();
        Vector3 up = Vector3.cross(right, forward).normalized();
        float x = p.fDot(right);
        float y = p.fDot(up);
        float z = p.fDot(forward);
        float fovScale = (float) resX / (float) (2.0f * Math.tan(Math.toRadians(globalFov * 0.5f)));
        if (z < 0)
            return null; //hinter Kamera

        float sx = (-x / z) * fovScale + resX * 0.5f;
        float sy = (-y / z) * fovScale + resY * 0.5f;

        return new Vector2(sx, sy);
    }
    private void xyAtR(Vector3 iniOr, double iniR, double amount, Color c, double[][] wireframeBuffer, int resX, int resY){
        Vector3 pointP1 = iniOr.add(new Vector3(0, iniR*amount, 0)), pointPm1 = iniOr.subtract(new Vector3(0, iniR*amount, 0));
        double h = amount * iniR;             // Höhe über Kugelmittelpunkt
        double r = Math.sqrt(iniR*iniR - h*h);
        //System.out.println(fact);
        renderSphereWireframe(r ,pointP1, c, wireframeBuffer, resX, resY);
        renderSphereWireframe(r ,pointPm1, c, wireframeBuffer, resX, resY);
    }
    public void renderWireframe(int resX, int resY) {
        long unixTime = System.currentTimeMillis();
        if (recacheObj != null) {
            reCache(getIndx(recacheObj));
            recacheObj = null;
        }
        double[][] wireframeBuffer = new double[resY][resX];
        Triangle[] tris = getAllTris();
        for (Triangle t : tris) {
            if(t instanceof SphereTri){
                Sphere s = t.getOwnerS();
                double iniR = s.getRadius();
                Vector3 iniOr = s.getOrigin();
                for (double d = 0; d <= 1 ; d+=0.15) {
                    xyAtR(iniOr, iniR, d, s.getColor(), wireframeBuffer, resX, resY);
                }
                xyAtR(iniOr, iniR, 0.95, skyColor, wireframeBuffer, resX, resY);
                xyAtR(iniOr, iniR, 0.999, skyColor, wireframeBuffer, resX, resY);

                continue;
            }
            Vector2 p0 = project(t.points[0], resX, resY);
            Vector2 p1 = project(t.points[1], resX, resY);
            Vector2 p2 = project(t.points[2], resX, resY);

            if (p0 == null || p1 == null || p2 == null)
                continue;
            Color prec = t.getOwner().getColor();
            int c = t.getOwner() instanceof ImportedObject3D ? prec.multiplied(1f).clamp().toRGB():prec.multiplied(1000f).clamp().toRGB();

            drawLine((int) p0.getX(), (int) p0.getY(), (int) p1.getX(), (int) p1.getY(), c, resX, resY,
                    wireframeBuffer);
            drawLine((int) p1.getX(), (int) p1.getY(), (int) p2.getX(), (int) p2.getY(), c, resX, resY,
                    wireframeBuffer);
            drawLine((int) p2.getX(), (int) p2.getY(), (int) p0.getX(), (int) p0.getY(), c, resX, resY,
                    wireframeBuffer);
        }

        TestImage.saveImg(wireframeBuffer, 0, -2, null);
        long unixTime2 = System.currentTimeMillis();
        System.out.println(numTri);
        System.out.println("rendering took: " + (unixTime2 - unixTime) + "ms");
    }
    private void renderSphereWireframe(double rad, Vector3 ori, Color c, double[][] wire, int resX, int resY) {
        int segments = 20; // je höher, desto runder
        double radius = rad;
        Vector3 origin = ori;

        Vector2[] projected = new Vector2[segments];
        for (int i = 0; i < segments; i++) {
            double angle = 2 * Math.PI * i / segments;
            // x-z Kreis in der horizontalen Ebene (Y konstant)
            Vector3 point = origin.add(new Vector3(
                radius * Math.cos(angle),
                0,
                radius * Math.sin(angle)
            ));
            projected[i] = project(point, resX, resY);
        }
        // Linien zwischen Segmenten zeichnen
        for (int i = 0; i < segments; i++) {
            Vector2 p0 = projected[i];
            Vector2 p1 = projected[(i + 1) % segments];
            if (p0 != null && p1 != null)
                drawLine((int) p0.getX(), (int) p0.getY(),
                        (int) p1.getX(), (int) p1.getY(),
                        c.multiplied(100f).clamp().toRGB(),
                        resX, resY, wire);
        }
        
}
    public Triangle[] getAllTris() {
        int numberOfTris = 0;
        for (int i = 0; i < object3ds.length; i++) {
            if (!object3ds[i].boundingBox.intersectRay(position, direction))
                continue;
            numberOfTris += object3ds[i].numberOfTris();
        }
        System.out.println("Number of Tris: " + numberOfTris);
        Triangle[] tris = new Triangle[numberOfTris];
        int tricounter = 0;
        for (int i = 0; i < object3ds.length; i++) {
            if (!object3ds[i].boundingBox.intersectRay(position, direction))
                continue;
            Triangle[] tempTris = object3ds[i].getTris();
            if (tempTris == null)
                continue;
            for (int j = 0; j < tempTris.length; j++) {
                tris[tricounter] = tempTris[j];
                if (j < 10 && !alr) {
                    alr = true;
                    System.out.println(tempTris[j].toString());
                } else if (j < 12 && !alr) {
                    alr = true;
                    System.out.println("...");
                }
                tricounter++;
            }
        }
        return tris;
    }

    // hit!!!
    public Hit intersectBVH(Vector3 rayOrigin, Vector3 rayDir) {
        return intersectNode(bvh, rayOrigin, rayDir, Double.POSITIVE_INFINITY);
    }

    private Hit intersectNode(BHVNode node, Vector3 origin, Vector3 dir, double closest) {
        // backface culling
        if (!node.box.intersectRay(origin, dir)) {
            if (!node.forSphere())
                return null; // bei sphere gibts sonst probleme mit reflektionen
        }

        Hit best = null;

        if (node.isLeaf()) {
            for (Triangle t : node.tris) {
                Vector3 p = t.getRayImpactPoint(origin, dir);
                if (p == null)
                    continue;

                double d = origin.distance(p);
                if (d < closest) {
                    closest = d;
                    best = new Hit(t, p, d, t.getOwner().getColor(), t.getOwner());
                }
            }
            return best;
        }

        Hit h1 = intersectNode(node.left, origin, dir, closest);
        if (h1 != null)
            closest = h1.dist;

        Hit h2 = intersectNode(node.right, origin, dir, closest);
        if (h1 != null && h2 != null)
            return h1.dist < h2.dist ? h1 : h2;
        if (h1 != null && h2 == null)
            return h1;
        return h2;
    }

    // RAYTRACE
    Color traceRay(Vector3 origin, Vector3 dir, int depth) {
        // zu weit
        if (depth > MAX_DEPTH)
            return skyColor;
        Hit hit = intersectBVH(origin, dir);
        // kein hit
        if (hit == null)
            return skyColor;
        Triangle tri = hit.tri;
        Vector3 hitPoint = hit.point();
        Vector3 normal = tri.getNormalAt(hitPoint, dir);
        Color baseColor = hit.color;
        Color localColor = calcLighting(baseColor, tri, dir, hitPoint);
        // keine reflektion
        if (!hit.owner.isReflective())
            return localColor.clamp();
        // reflektion
        Vector3 reflectDir = dir.reflect(normal).normalized();
        Vector3 reflectOrigin = hitPoint.add(normal.multiply(EPS));
        Color reflected = traceRay(reflectOrigin, reflectDir, depth + 1);
        float r = hit.owner.getReflectivity();
        return localColor.multiplied(1 - r).add(reflected.multiplied(r)).clamp();
    }

    // SCHATTEN!
    public boolean isInShadow(Vector3 point, Vector3 lightPos) {
        Vector3 toLight = lightPos.subtract(point);
        double maxDist = toLight.length();
        Vector3 dir = toLight.normalized();
        // gegen selbstschatten
        Vector3 origin = point.add(dir.multiply(1e-4));
        return intersectBVHForShadow(origin, dir, maxDist);
        /*
         * Hit shadowHit = intersectBVH(origin, dir);
         * if (shadowHit == null) return false;
         * return shadowHit.dist < maxDist;
         */
    }

    private boolean intersectBVHForShadow(Vector3 origin, Vector3 dir, double maxDist) {
        return intersectNodeForShadow(bvh, origin, dir, maxDist);
    }

    private boolean intersectNodeForShadow(BHVNode node, Vector3 origin, Vector3 dir, double maxDist) {
        if (!node.box.intersectRay(origin, dir))
            return false;
        if (node.isLeaf()) {
            for (Triangle t : node.tris) {
                double d = t.getImpactDistance(origin, dir);
                if (d > 0 && d < maxDist) {
                    return true; // Sofort return bei erstem Hit!
                }
            }
            return false;
        }
        // early exit
        if (intersectNodeForShadow(node.left, origin, dir, maxDist))
            return true;
        return intersectNodeForShadow(node.right, origin, dir, maxDist);
    }

    // LIGHTING
    private Color calcLighting(Color tempC, Triangle tri, Vector3 dir, Vector3 impact) {
        Color calcColor;
        if (lights == null) {
            calcColor = tempC;
        } else {
            calcColor = skyColor.multiplied(0.1);
            Vector3 normalF = tri.getNormalAt(impact, dir);
            Color litColor = new Color(tempC);
            litColor.multiply(ambient);
            for (Light l : lights) {
                if (isInShadow(impact, l.getPosition()))
                    continue;
                if (l.getPosition() == null)
                    continue;

                Vector3 lightDir = l.getPosition().subtract(impact).normalized();
                float distToLight = l.getPosition().distance(impact);
                float att = 1.0f / (1.0f + distToLight * distToLight * 0.05f);
                float diff = Math.max(0, Vector3.dot(normalF, lightDir));
                diff *= att;
                Color diffC = tempC.multiplied(diff * l.getIntensity()).crossMult(l.getColor());

                // Specular (Blinn-Phong)
                if (diff > 0 && tri.getOwner().getSpecularStrength() > 0) {
                    // View direction (von Impact zur Kamera)
                    Vector3 viewDir = position.subtract(impact).normalized();

                    // Blinn-Phong: Halfway vector
                    Vector3 halfwayDir = lightDir.add(viewDir).normalized();

                    float spec = (float) Math.pow(
                            Math.max(Vector3.dot(normalF, halfwayDir), 0.0f),
                            tri.getOwner().getShininess());

                    spec *= att * tri.getOwner().getSpecularStrength() * l.getIntensity();

                    // Specular Farbe (normalerweise Lichtfarbe oder weiß)
                    Color specularColor = l.getColor().multiplied(spec);

                    // Oder für weiße Highlights:
                    // Color specularColor = Color.SPECULAR_WHITE().multiplied(spec);
                    diffC = diffC.add(specularColor);
                }
                calcColor = calcColor.add(diffC);
            }
            calcColor = calcColor.clamp();
        }
        return calcColor;
    }

    private double[][] depthImageMeasure(int IresX, int IresY, boolean colored) {
        double[][] imagematrix = new double[IresY][IresX];
        Color[][] colors = new Color[IresY][IresX];
        for (int i = 0; i < imagematrix.length; i++) {
            for (int j = 0; j < imagematrix[i].length; j++) {
                imagematrix[i][j] = -1;
                if (colored)
                    colors[i][j] = new Color(-1, -1, -1);
            }
        }
        double aspect = (double) IresX / IresY;
        double fov = Math.tan(Math.toRadians(globalFov) / 2.0);

        // multithread
        if (multithread) {
            int numThreads = Runtime.getRuntime().availableProcessors();
            ExecutorService executor = Executors.newFixedThreadPool(numThreads);
            List<Future<?>> futures = new ArrayList<>();
            for (int t = 0; t < numThreads; t++) {
                final int threadIndex = t;
                futures.add(executor.submit(() -> {
                    for (int y = threadIndex; y < IresY; y += numThreads) {
                        for (int x = 0; x < IresX; x++) {
                            double px = (2 * ((x + 0.5) / IresX) - 1) * fov * aspect;
                            double py = (1 - 2 * ((y + 0.5) / IresY)) * fov;
                            Vector3 dir = new Vector3(px, py, 1);
                            dir.rotate(rotation);
                            dir.normalize();
                            double minDist = 1f / 0;
                            // mit bhv
                            if (bhvBOOL) {
                                Hit hit = intersectBVH(position, dir);
                                if (hit != null) {
                                    minDist = hit.dist;
                                    if (colored) {
                                        // Vector3 normal = hit.tri.getNormalAt(hit.point(), dir);
                                        // ? hit.tri.getNormalAt(hit.point(), dir)
                                        // : hit.tri.getNormalFacing(dir);

                                        // Lichtberechnung
                                        Color c;
                                        if (!raytracebool) {
                                            c = calcLighting(hit.color, hit.tri, dir, hit.point());
                                        } else {
                                            c = traceRay(position, dir, 0);
                                        }
                                        colors[y][x] = c;
                                    }
                                }
                            } else {

                                // ohne bhv
                                for (int i = 0; i < object3ds.length; i++) {
                                    // Bounding-Box early-out
                                    if (!object3ds[i].boundingBox.intersectRay(position, dir))
                                        continue;

                                    // numberOfOp++;
                                    Triangle[] tris = cachedTris[i];
                                    Color tempC = cachedColors[i];
                                    for (int j = 0; j < tris.length; j++) {
                                        // backface culling
                                        Vector3 normal = tris[j].getNormal();
                                        if (Vector3.dot(normal, dir) > 0)
                                            continue;

                                        // Vector3 impact = tris[j].getRayImpactPoint(position, dir);
                                        // if (impact == null)
                                        // continue;

                                        double dist = tris[j].getImpactDistance(position, dir);
                                        // position.distance(impact);
                                        if (dist >= 0 && dist < minDist) {
                                            minDist = dist;
                                            if (colored) {
                                                Vector3 impact = tris[j].getRayImpactPoint(position, dir);
                                                Color c;
                                                if (!raytracebool) {
                                                    c = calcLighting(tempC, tris[j], dir, impact);
                                                } else {
                                                    c = traceRay(position, dir, 0);
                                                }
                                                colors[y][x] = c;
                                            }
                                        } // else{
                                          // if(colored){
                                          // colors[y][x] = new Color(-1, -1, -1);
                                          // }
                                          // }
                                    }
                                }
                            }

                            imagematrix[y][x] = (minDist < maxDist) ? minDist : -1;
                        }
                    }
                }));
            }
            // warten bis alle Threads fertig sind
            for (Future<?> f : futures) {
                try {
                    f.get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }

            executor.shutdown();

            // System.out.println("Number of Operations: " + numberOfOp);
            numberOfOp = 0;
            if (colored)
                this.colors = colors;
            return imagematrix;
        }
        // no backface culling yet
        for (int y = 0; y < IresY; y++) {
            for (int x = 0; x < IresX; x++) {
                double px = (2 * ((x + 0.5) / IresX) - 1) * fov * aspect;
                double py = (1 - 2 * ((y + 0.5) / IresY)) * fov;
                Vector3 dir = new Vector3(px, py, 1);
                dir.rotate(rotation);
                dir.normalize();
                double min = 1 / 0.0;
                for (int i = 0; i < object3ds.length; i++) {
                    if (!object3ds[i].boundingBox.intersectRay(position, dir))
                        continue;
                    numberOfOp++;
                    Triangle[] tris = object3ds[i].getTris();
                    for (int j = 0; j < tris.length; j++) {
                        Vector3 impact = tris[j].getRayImpactPoint(position, dir);
                        if (impact == null)
                            continue;
                        double dist = position.distance(impact);
                        // double dist = tris[i].getImpactDistance(position, dir);
                        if (dist < 0)
                            continue;
                        min = dist >= 0 && dist < min ? dist : min;
                    }
                }
                // 30 als maxDist standardmäßig
                imagematrix[y][x] = min < maxDist ? min : -1;
            }
        }
        System.out.println("Number of Operations: " + numberOfOp);
        numberOfOp = 0;
        return imagematrix;
    }

    public void changePos(Vector3 v3) {
        this.position = v3;
    }

    public void changeDir(Vector3 v3) {
        this.direction.changeTo(v3);
    }

    public Vector3 getDir() {
        return this.direction;
    }

    public Vector3 getPos() {
        return this.position;
    }

    public void rotate(double amount) {
        rotation += amount;
    }
}
