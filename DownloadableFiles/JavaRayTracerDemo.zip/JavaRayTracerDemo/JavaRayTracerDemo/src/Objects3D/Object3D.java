package Objects3D;

import Primitives3DandUtil.*;
import Primitives3DandUtil.Color.SurfaceType;
import SceneObjects.Camera;

public class Object3D {
    public Vector3 origin;
    public AABB boundingBox = new AABB(origin, origin);
    private Color color = Color.WHITE();
    private float reflectivity = 0.7f;
    private double shininess = 64;
    private float specStrength = 0.8f;
    public Object3D(Vector3 origin){
        if(origin == null) return;
        this.origin = origin;
    }
    public Vector3 getOrigin(){
        return origin;
    }
    public int numberOfTris() {
        return 0;
    }
    public Triangle[] getTris(){
        return null;
    }
    public Color getColor(){
        return color;
    }
    public void setColor(Color color){
        this.color = color;
       // Camera.recacheObj = this;
        Camera.onlyCol = true;
    }
    public SurfaceType getType(){
        return this.color.getSurfaceType();
    }
    public void RotX(int amount){
        //it doesnt do anything here lol
        Camera.recacheObj = this;
    }
    public void RotY(int amount){
        //it doesnt do anything here lol
        Camera.recacheObj = this;
    }
    public void RotZ(int amount){
        //it doesnt do anything here lol
        Camera.recacheObj = this;
    }
    public void setSurfaceType(SurfaceType type, float reflectivity){
        this.color.setSurfaceType(type);
        this.reflectivity = reflectivity;
    }
    public void setSurfaceType(float reflectivity){
        this.color.setSurfaceType(reflectivity>0?SurfaceType.REFLECTIVE:SurfaceType.NORMAL);
        this.reflectivity = reflectivity;
    }
    public boolean isReflective() {
        return getType() == SurfaceType.REFLECTIVE;
    }
    public float getReflectivity(){
        return reflectivity;
    }
    public double getShininess() {
        return shininess;
    }
    public float getSpecularStrength() {
        return specStrength;
    }
     public void setShininess(double shininess) {
        this.shininess = shininess;
    }
    public void setSpecularStrength(float specStrength) {
        this.specStrength = specStrength;
    }
    public void PLASTIC(){
        setSurfaceType(0);
        setShininess(30);
        setSpecularStrength(0.5f);
    }
    public void METAL(){
        setSurfaceType(0.2f);
        setShininess(100);
        setSpecularStrength(0.7f);
    }
    public void MIRROR(){
        setSurfaceType(0.9f);
        setShininess(1000);
        setSpecularStrength(0.95f);
    }
    public void MATT(){
        setSurfaceType(0.05f);
        setShininess(4);
        setSpecularStrength(0.2f);
    }
}
