package Primitives3DandUtil;

public class Color {
    private byte r,g,b;
    private SurfaceType type;
    public enum SurfaceType{
        NORMAL,
        REFLECTIVE;
    }
    private static byte encode(int v){
        // clamp: -1 .. 254
        if(v < -1) v = -1;
        if(v > 254) v = 254;
        return (byte)(v == -1 ? 127 : v - 128);
    }
    private int gammaCorrect(double v){
        // clamp zuerst
        if(v < 0) v = 0;
        if(v > 255) v = 255;
        return (int)(Math.pow(v / 255.0, 1/2.2) * 255.0 + 0.5);
    }

    public int toRGBGamma() {
        Color c = new Color(this.clamp());
        setR(c.getR());
        setG(c.getG());
        setB(c.getB());

        return (255 << 24) | 
            (gammaCorrect(getR()) << 16) | 
            (gammaCorrect(getG()) << 8) | 
            gammaCorrect(getB());
    }
    private static int decode(byte b){
        return b==127?-1:b + 128;
    }
     public Color(double r, double g, double b){
        this.r = encode((int)r); this.g = encode((int)g); this.b = encode((int)b);
        this.type = SurfaceType.NORMAL;
    }
    public Color(short r, short g, short b){
        this((double)r,(double)g,(double)b);
        this.type = SurfaceType.NORMAL;
    }
    private Color(SurfaceType type, double r, double g, double b){
        this((double)r,(double)g,(double)b);
        this.type = type;
    }
    public Color(Color c2){
        this((double)c2.getR(),(double)c2.getG(),(double)c2.getB());
        this.type = c2.getSurfaceType();
    }
    public static Color createReflectiveColor(double r, double g, double b){
        return new Color(SurfaceType.REFLECTIVE, r, g, b);
    }
    public void setR(double r){
        this.r = encode((int)r);
    }
    public void setG(double g){
        this.g = encode((int)g);
    }
    public void setB(double b){
        this.b = encode((int)b);
    }
    public void setSurfaceType(SurfaceType type){
        this.type = type;
    }
    private static int clampInt(int v){
        if(v < 0) return 0;
        if(v > 254) return 254;
        return v;
    }
    public double getR() {return (double)decode(r);}
    public double getG() {return (double)decode(g);}
    public double getB() {return (double)decode(b);}
    //short versions
    public short getR_FAST() {return (short)decode(r);}
    public short getG_FAST() {return (short)decode(g);}
    public short getB_FAST() {return (short)decode(b);}
    public SurfaceType getSurfaceType() {return type;}
    public void multiply(double d){
        r*=d; g*=d; b *=d;
    }
    public int toRGB() {
        // RGB als 0xAARRGGBB (Alpha immer 255 = voll deckend)
        return (255 << 24) |      // Alpha (voll deckend)
               (clamp(getR_FAST()) << 16) | // Rot
               (clamp(getG_FAST()) << 8) |  // Grün
               clamp(getB_FAST());          // Blau
    }
    int clamp(int i){
        return i<255?i:255;
    }
    public Color multiplied(double d){
        return new Color(getR()*d, getG()*d, getB() *d);
    }
    public Color crossMult(Color otherC){
        double nR = (decode(this.r) / 255.0) * (otherC.getR() / 255.0) * 255;
        double nG = (decode(this.g) / 255.0) * (otherC.getG() / 255.0) * 255;
        double nB = (decode(this.b) / 255.0) * (otherC.getB() / 255.0) * 255;
        return new Color(nR<255?nR:255, nG<255?nG:255, nB<255?nB:255);
    }
    public Color add(Color otherC){
        if(otherC==null) return this;
        int nR = decode(r)+otherC.getR_FAST();
        int nG = decode(g)+otherC.getG_FAST();
        int nB = decode(b)+otherC.getB_FAST();
        return new Color(nR<255?nR:255, nG<255?nG:255, nB<255?nB:255);
    }
    //static ones
    public static Color RED(){
        return new Color(255, 0, 0);
    }
    public static Color GREEN(){
        return new Color(0, 255, 0);
    }
    public static Color BLUE(){
        return new Color(0, 0, 255);
    }
    public static Color WHITE(){
        return new Color(255, 255, 255);
    }
    public static Color BLACK(){
        return new Color(0, 0, 0);
    }
    public static Color NEGATIVE(){
        return new Color(-1,-1,-1);
    }
    public String toString(){
        return "R:" + r + "G" + g + "B" +b;
    }
    public boolean equals(Color c){
        return this.r == c.getR() && this.g == c.getG() && this.b == c.getB();
    }
    public Color clamp(){
        return new Color(
            clampInt((int)getR()),
            clampInt((int)getG()),
            clampInt((int)getB())
        );
    }
}
