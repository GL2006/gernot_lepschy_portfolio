@echo off
setlocal

cd /d "%~dp0"

set "APP_JAR=RINGS.jar"
if not exist "%APP_JAR%" (
    if exist "RINGS-new.jar" (
        set "APP_JAR=RINGS-new.jar"
    )
)

if not exist "%APP_JAR%" (
    echo Fehler: RINGS.jar wurde nicht gefunden.
    echo Lege RINGS.jar in denselben Ordner wie openhere.bat.
    pause
    exit /b 1
)

set "JAVA_EXE="

if exist "jdk\bin\java.exe" set "JAVA_EXE=%CD%\jdk\bin\java.exe"
if not defined JAVA_EXE if exist "jre\bin\java.exe" set "JAVA_EXE=%CD%\jre\bin\java.exe"
if not defined JAVA_EXE if exist "portable-jdk\bin\java.exe" set "JAVA_EXE=%CD%\portable-jdk\bin\java.exe"
if not defined JAVA_EXE if exist "java\bin\java.exe" set "JAVA_EXE=%CD%\java\bin\java.exe"
if not defined JAVA_EXE set "JAVA_EXE=java"

"%JAVA_EXE%" -jar "%APP_JAR%"

if errorlevel 1 (
    echo.
    echo Java konnte nicht gestartet werden oder das Programm wurde mit einem Fehler beendet.
    echo Fuer portable Nutzung: Lege einen JDK-Ordner neben diese Datei, z.B.:
    echo %CD%\jdk\bin\java.exe
    echo.
    pause
    exit /b 1
)

echo.
echo bye
pause

endlocal
