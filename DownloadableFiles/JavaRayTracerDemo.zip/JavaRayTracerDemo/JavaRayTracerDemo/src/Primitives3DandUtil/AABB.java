package Primitives3DandUtil;

public class AABB {
    Vector3 min, max;
    public AABB(Vector3 min, Vector3 max){
        if(min == null || max == null) return;
        this.min = min;
        this.max = max;
    }
    public boolean intersectRay(Vector3 ro, Vector3 rd) {
        float tmin = (min.getX() - ro.getX()) / rd.getX();
        float tmax = (max.getX() - ro.getX()) / rd.getX();
        if (tmin > tmax) { float t=tmin; tmin=tmax; tmax=t; }

        float tymin = (min.getY() - ro.getY()) / rd.getY();
        float tymax = (max.getY() - ro.getY()) / rd.getY();
        if (tymin > tymax) { float t=tymin; tymin=tymax; tymax=t; }

        if ((tmin > tymax) || (tymin > tmax)) return false;

        float tzmin = (min.getZ() - ro.getZ()) / rd.getZ();
        float tzmax = (max.getZ() - ro.getZ()) / rd.getZ();
        if (tzmin > tzmax) { float t=tzmin; tzmin=tzmax; tzmax=t; }

        return true;
    }
    public static AABB fromTriangles(Triangle[] tris) {
        Vector3 min = new Vector3(1f/0,1f/0,1f/0);
        Vector3 max = new Vector3(-1f/0,-1f/0,-1f/0);


        for (Triangle t : tris) {
            for (Vector3 p : t.points) {
                min = new Vector3(
                    Math.min(min.getX(), p.getX()),
                    Math.min(min.getY(), p.getY()),
                    Math.min(min.getZ(), p.getZ())
                );
                max = new Vector3(
                    Math.max(max.getX(), p.getX()),
                    Math.max(max.getY(), p.getY()),
                    Math.max(max.getZ(), p.getZ())
                );
            }
        }
        return new AABB(min, max);
    }
    public Vector3 getSize() {
        return max.subtract(min);
    }
}
