package Support;

public class Table {
    //to get values for N
    public static void test() {
        for (double i = -4; i < 4; i+=0.1) {
            System.out.print(String.format("%5.2f", dichte(i)));
            double calcL = dichte(i) / dichte(0);
             for (int j = 0; j < (int)(calcL*75); j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        System.out.println(approxIntegralZwischen(-1, 1, 0.01));

        for (double i = -4; i <= 4; i+=0.1) {
            System.out.print(String.format("%5.2f", psi(i)));
            double calcL = psi(i) / psi(3.0);
             for (int j = 0; j < (int)(calcL*75); j++) {
                System.out.print("*");
            }
            System.out.println();
        }

        System.out.println();
        System.out.println(D(1.96));
        System.out.println();
        System.out.println(invertPsi(0.75));
        System.out.println();
        System.out.println(invertD(0.95));
    }
    public static double[][] fullTable(){
        double[][] data = new double[300][4];

        return data;
    }
    private String allValues(){
        String str = "";
        str += "";
        return str;
    }
    public static double dichte(double z){
        //1/2pi * e^-t^2/2
        double firstComp = 1/ Math.sqrt(Math.PI*2);
        double exp = -0.5 * (z * z);
        double eExpr = Math.pow(Math.E , exp);
        return firstComp * eExpr;
    }
    private static double approxIntegralZwischen(double from, double to, double stepsize){
        stepsize = stepsize <= 0 ? 0.1:stepsize;
        double sum = 0;
        for (double d = from; d <= to; d+=stepsize) {
            //avg aus ober und untersumme
            double addo = dichte(d) * stepsize;
            double nextindex = (d + stepsize < to)?d+stepsize:to;
            double add = (addo + dichte(nextindex)*stepsize) / 2;
            sum += add > 0 ? add:0;
        }
        return sum;
    }public static double accPsi(double z){
        double result = (z != 0) ? (z>0)?approxIntegralZwischen(-100, z, 0.01): (1-approxIntegralZwischen(-100, -z, 0.01)):0.5;
        return result;
    }
    public static double psi(double z){
        double result = (z != 0) ? (z>0)?approxIntegralZwischen(-100, z, 0.01): (1-approxIntegralZwischen(-100, -z, 0.01)):0.5;
        return round3(result);
    }
    public static double psi(double z, double prec){
        double result = (z != 0) ? (z>0)?approxIntegralZwischen(-100, z, prec): (1-approxIntegralZwischen(-100, -z, prec)):0.5;
        return round3(result);
    }
    public static double D(double z){
        double result = approxIntegralZwischen(-z, z, 0.01);
        return round3(result);
    }
    public static double D(double z, double prec){
        double result = approxIntegralZwischen(-z, z, prec);
        return round3(result);
    }
    public static double invertPsi(double p){
        return round3(accInvertPsi(p));
    }
    public static double accInvertPsi(double p){
        if(p <= 0 || p > 1) return -999;
        if(Math.abs(p-0.5)< 0.001) return 0;

        double lowerBound = -7;
        double higherBound = 7;
        double mid = 0;
        double precision = 1e-15;
        while(higherBound-lowerBound > precision){
            mid = (lowerBound + higherBound)/2;
            double currPsi = psi(mid, 0.001);
            if(currPsi < p){
                lowerBound = mid;
            }else{
                higherBound = mid;
            }
        }
        return mid;
    }
    public static double accInvertD(double p){
        if(p <= 0 || p > 1) return -999;
        if(Math.abs(p-0.5)< 0.001) return 0;

        double lowerBound = -7;
        double higherBound = 7;
        double mid = 0;
        double precision = 1e-15;
        while(higherBound-lowerBound > precision){
            mid = (lowerBound + higherBound)/2;
            double currPsi = D(mid, 0.001);
            if(currPsi < p){
                lowerBound = mid;
            }else{
                higherBound = mid;
            }
        }
        return mid;
    }
    public static double invertD(double p){
        return round3(accInvertD(p));
    }

    static double round3(double d){
        return Math.round(d * 1000.0)/1000.0;
    }

}
