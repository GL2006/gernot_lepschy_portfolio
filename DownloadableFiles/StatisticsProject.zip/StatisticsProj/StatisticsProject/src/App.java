import Support.*;

public class App {
    public static NormalVerteilung[] nv = new NormalVerteilung[7];
    public static BinomialVerteilung[] bv = new BinomialVerteilung[7];
    public static int normalIndex = -1, binIndex = -1;
    public static void main(String[] args) throws Exception {
       // tests2();
        println("Welcome to this little programm to calculate Probabilities!\nMade by Gernot Lepschy");
        println("Can you read the following text? (y/n)");
        println("\u001B[31m" + "CAN YOU READ THIS IN RED??????" + "\u001B[0m");
        char readable = ' ';
        do{
            readable = In.readChar();
            if(readable != 'y'&& readable != 'n'){
                println("Could you read it? (y/n)");
            }
        }while(readable != 'y'&& readable != 'n');
        NormalVerteilung.setColor(readable == 'y'); BinomialVerteilung.setColor(readable == 'y');
        boolean done = false;
        do{
            println("Programmed by Gernot Lepschy, 22.12.2025");
            println("--------------------------------------------------------------------------------------------\n"+
                  "|                                What do you want to do?                                   |\n" +
                  "--------------------------------------------------------------------------------------------"
            );
            println("(1): Normal Distribution\n(2): Binomial Distribution\n(3): Settings\n(4): Quit");
            char input = ' ';
            do{
                input= In.readChar();
                if(input != '1' && input != '2' && input != '3'){
                    println("(1),(2),(3),(4)?");
                }
            }while(input != '1' && input != '2' && input != '3'&& input != '4');
            switch (input) {
                case '1':
                    if(normalIndex == -1){
                        normalIndex++;
                        createNormal();
                    }else{
                        allNormals();
                    }
                    break;
                case '2':
                     if(binIndex == -1){
                        binIndex++;
                        createBin();
                    }else{
                        allBin();;
                    }
                    break;
                case '3':
                    char YN3 = ' ';
                    do{
                        println("Color on? (y,n)");
                        YN3 = In.readChar();
                    }while(YN3 != 'n' && YN3 != 'y');
                    NormalVerteilung.setColor(YN3 == 'y'); BinomialVerteilung.setColor(YN3 == 'y');
                    boolean resbool = true;
                    while(resbool){
                        char RES = ' ';
                        do{
                            println("Set the graph resolution to Small ('S'), Medium ('M'), Large ('L') or High ('H')\n"+
                                "'L' is standard. So which one? I'll show a test afterwards"
                            );
                            RES = In.readChar();
                        }while(RES != 'S' && RES != 'M' && RES != 'L' && RES != 'H');
                        NormalVerteilung tempNV = new NormalVerteilung(0, 1);
                        switch (RES) {
                            case 'S': case 's': 
                                BinomialVerteilung.setRes(60, 10); NormalVerteilung.setRes(60, 10);
                                System.out.println(tempNV);
                                break;
                            case 'M':case 'm': 
                                BinomialVerteilung.setRes(100, 18); NormalVerteilung.setRes(100, 18);
                                System.out.println(tempNV);
                                break;
                            case 'L':case 'l': 
                                BinomialVerteilung.setRes(120, 22); NormalVerteilung.setRes(120, 22);
                                System.out.println(tempNV);
                                break;
                            case 'H':case 'h':
                                BinomialVerteilung.setRes(200, 30); NormalVerteilung.setRes(300, 40);
                                System.out.println(tempNV);
                                break;
                            default:
                                break;
                        }
                        YN3 = ' ';
                        do{
                            println("Is this okay? (y/n)");
                            YN3 = In.readChar();
                        }while(YN3 != 'n' && YN3 != 'y');
                        resbool = YN3 == 'n';
                    }
                default:
                    YN3 = ' ';
                    do{
                        println("Want to quit? (y/n)?");
                        YN3 = In.readChar();
                    }while(YN3 != 'n' && YN3 != 'y');
                    done = YN3 == 'y';
                    break;
            }
        }while(!done);
        println("Bye!");
    }
    public static void allNormals(){
        println("SELECT:");
        println("There are a maximum amount of 7 distributions, if you create a new one even so, the oldest one will be overwritten");
        int highestI = 0;
        for (int i = 0; i < nv.length; i++) {
            if(nv[i]!=null){
                System.out.println("(" + (i+1) + ") NormalDistr.Nr." + (i+1) +": my = " + nv[i].getMy() + ": SD = " + nv[i].getStandardDeviation());
                highestI = i;
            }
        }
        System.out.println("(" + (highestI + 2) + ") New NormalDistr.");
        println("(" + (highestI + 3) + ") Back");
        char input = ' ';
        do{
            input= In.readChar();
            if(input - '0' < 1 || input - '0' > 10){
                println("(1),(2),(3),(4),...?");
            }
        }while(input - '0' < 1 || input - '0' > 10 || input - '0' > highestI+2);
        int inInt = input - '0';
        if(inInt == highestI +3){return;}
        if(inInt == highestI +2){normalIndex = normalIndex<highestI?normalIndex+1:0; createNormal();}
        println(nv[inInt-1].toString());
        NormalOp(inInt-1);
    }
    public static void allBin(){
        println("SELECT:");
        println("There are a maximum amount of 7 distributions, if you create a new one even so, the oldest one will be overwritten");
        int highestI = 0;
        for (int i = 0; i < bv.length; i++) {
            if(bv[i]!=null){
                System.out.println("(" + (i+1) + ") Bin.Distr.Nr." + (i+1) +": n = " + bv[i].getN() + ": p = " + bv[i].getP());
                highestI = i;
            }
        }
        System.out.println("(" + (highestI + 2) + ") New Bin.Distr.");
        println("(" + (highestI + 3) + ") Back");
        char input = ' ';
        do{
            input= In.readChar();
            if(input - '0' < 1 || input - '0' > 10){
                println("(1),(2),(3),(4),...?");
            }
        }while(input - '0' < 1 || input - '0' > 10 || input - '0' > highestI+2);
        int inInt = input - '0';
        if(inInt == highestI +3){return;}
        if(inInt == highestI +2){binIndex = binIndex<highestI?normalIndex+1:0; createBin();}
        println(bv[inInt-1].toString());
        BinOp(inInt-1);
    }
    public static void createBin(){
        println("--------------------------------------------------------------------------------------------\n"+
              "|                                Binominal Distribution:                                      |\n" +
              "--------------------------------------------------------------------------------------------"
        );
        //my
        println("n<500 !!!!");
        print("n (sample size): ");
        int para01 = In.readInt();
        while(para01<=0|| para01 > 500){
            println("n<500 !!!!");
            print("n (sample size): ");
            para01 = In.readInt();
        }
        println("My = " + para01 + "\nIs that right? (y/n)");
        char ynChar = ' ';
        do{
            ynChar = In.readChar();
            if(ynChar == 'n'){
                print("n (sample size): ");
                para01 = In.readInt();
                if(para01 > 500 || para01 <= 0){
                    para01 = 10;
                    System.out.println("NOT ALLOWED [sorry :(]");
                }
                println("n = " + para01 + "\nIs that right? (y/n)");
            }
        }while(ynChar != 'y');
        //SD
        print("Probability (p): ");
        double para02 = In.readDouble();
        if(para02 > 100 || para02 < 0){
            para02 = 0.5;
            System.out.println("NOT ALLOWED");
        }
        println("p = " + para02 + "\nIs that right? (y/n)");
        ynChar = ' ';
        do{
            ynChar = In.readChar();
            if(ynChar == 'n'){
                print("p: ");
                para02 = In.readDouble();
                if(para02 > 100 || para02 < 0){
            para02 = 0.5;
            System.out.println("NOT ALLOWED");
        }
                println("p = " + para02 + "\nIs that right? (y/n)");
            }
        }while(ynChar != 'y');
        bv[binIndex] = new BinomialVerteilung(para01, para02);
        println(bv[binIndex].toString());
        BinOp(binIndex);
    } 
    public static void createNormal(){
        println("--------------------------------------------------------------------------------------------\n"+
              "|                                Normal Distribution:                                        |\n" +
              "--------------------------------------------------------------------------------------------"
        );
        //my
        print("My (E(X)): ");
        double para01 = In.readDouble();
        println("My = " + para01 + "\nIs that right? (y/n)");
        char ynChar = ' ';
        do{
            ynChar = In.readChar();
            if(ynChar == 'n'){
                print("My (E(X)): ");
                para01 = In.readDouble();
                println("My = " + para01 + "\nIs that right? (y/n)");
            }
        }while(ynChar != 'y');
        //SD
        print("Standard Deviation (SD): ");
        double para02 = In.readDouble();
        println("SD = " + para02 + "\nIs that right? (y/n)");
        ynChar = ' ';
        do{
            ynChar = In.readChar();
            if(ynChar == 'n'){
                print("Standard Deviation (SD): ");
                para02 = In.readDouble();
                println("SD = " + para02 + "\nIs that right? (y/n)");
            }
        }while(ynChar != 'y');
        nv[normalIndex] = new NormalVerteilung((double)para01, (double)para02);
        println(nv[normalIndex].toString());
        NormalOp(normalIndex);
    }
    public static void BinOp(int index){
        boolean done = false;
        while(!done){
            println("----------------------------------------------------------------------------------------------\n"+
                    "|                                Binomial Distribution Operations:                           |\n" +
                    "----------------------------------------------------------------------------------------------\n" +
                    "-------->>>>>please note that these are all approximations and not 100% accurate<<<<<---------"
            );
            println("(1): P(X<k)\n(2): P(X<=k)\n(3): P(X=k)\n(4): P(X>k)\n(5): P(X>=k)\n(6): E(X)\n(7): SD(X) // V(X)\n(8):k(%) [for P(X<k) = %]\n"+
                    "(9): P(a<X<b)\n(a): New Binomial Distribution\n(b): Create Normal Distribution out of this Binomial Distribution\n(c): quit");
            char input = ' ';
            do{
                input= In.readChar();
                if(input != '1' && input != '2' && input != '3'&& input != '4' && input != '5' && input != '6' && input != '7'&&input != '8'&&input != '9'&&input != 'a'&&input != 'b'&&input != 'c'){
                    println("(1),(2),(3),(4),(5),(6),(7),(8),(9),(a),(b),(c)?");
                }
            }while(input != '1' && input != '2' && input != '3' && input != '4' && input != '5' && input != '6' && input != '7'&&input != '8'&&input != '9'&&input != 'a'&&input != 'b'&&input != 'c');
           // println("please only enter integer numbers!");
            switch (input) {
                case '1':
                    print("P(X<k) for k = ");
                    int i = In.readInt();
                    println(bv[index].PlessPrint(i));
                    break;
                case '2':
                    print("P(X<=k) for k = ");
                    int i2 = In.readInt();
                    println(bv[index].PlessEqPrint(i2));
                    break;
                case '3':
                    print("P(X=k) for k = ");
                    int i3 = In.readInt();
                    println(bv[index].EqPrint(i3));
                    break;
                case '4':
                    print("P(X>k) for k = ");
                    int i4 = In.readInt();
                    println(bv[index].PmorePrint(i4));
                    break;
                case '5':
                    print("P(X>=k) for k = ");
                    int i5 = In.readInt();
                    println(bv[index].PmoreEqPrint(i5));
                    break;
                case '6':
                    println("E(X) = " + round3((double)bv[index].getN() * (double)bv[index].getP()));
                    break;
                case '7':
                    double V = (double)bv[index].getN() * (double)bv[index].getP() * (1-(double)bv[index].getP());
                    double SD = Math.sqrt(V);
                    println("V(X) = " + round3(V) + ", SD(X) = sqrt(V(X) = " + SD);
                    break;
                case '8':
                    //(8):k(%) [for P(X<k) = %]
                    println("please note that this operation is particularly inacurate ;)"+
                        "\nlike here even more so than in the normal distribution, okay?"
                    );
                    print("P(X<k) = ");
                    double d6 = In.readDouble();
                    d6 = d6 < 1?d6:d6/100;
                    println(bv[index].invPxPrint(d6));
                    break;
                case '9':
                    println("P(a<X<b)");
                    print("a = ");
                    int i9 =  In.readInt();
                    print("b = ");
                    int i9_2 = In.readInt();
                    println(bv[index].PbetwPrint(i9, i9_2));
                    break;
                case 'a':
                    createBin();
                    done = true;
                    break;
                case 'b':
                    //to normal
                    done = true;
                    double my = (double)bv[index].getN() * bv[index].getP();
                    double sd = my * (1-bv[index].getP());
                    sd = Math.sqrt(sd);
                    normalIndex = normalIndex+1<7?normalIndex+1:0;
                    nv[normalIndex] = new NormalVerteilung(my, sd);
                    println("my: " + nv[normalIndex].getMy() + "SD" + nv[normalIndex].getStandardDeviation());
                    println(nv[normalIndex].toString());
                    NormalOp(normalIndex);
                    break;
                default:
                    done = true;
                    break;
            }
        }
    }   
    static double round3(double d){
        return Math.round(d * 1000.0)/1000.0;
    }
    public static void NormalOp(int index){
        boolean done = false;
        while(!done){
            println("----------------------------------------------------------------------------------------------\n"+
                    "|                                Normal Distribution Operations:                             |\n" +
                    "----------------------------------------------------------------------------------------------\n" +
                    "-------->>>>>please note that these are all approximations and not 100% accurate<<<<<---------"
            );
            println("(1): P(X<x)\n(2): P(X>x)\n(3): P(X=x)\n(4): D(x) [symmetrical around my]\n(5): x(%) [for P(X<x) = %]\n"+
                    "(6): x(%) [for D(x) = %, symmetrical around my]\n(7): New normal Distribution\n(8): quit");
            char input = ' ';
            do{
                input= In.readChar();
                if(input != '1' && input != '2' && input != '3'&& input != '4' && input != '5' && input != '6' && input != '7'&&input != '8'){
                    println("(1),(2),(3),(4),(5),(6),(7),(8)?");
                }
            }while(input != '1' && input != '2' && input != '3' && input != '4' && input != '5' && input != '6' && input != '7'&&input != '8');
           // println("please only enter integer numbers!");
            switch (input) {
                case '1':
                    print("P(X<x) for x = ");
                    double d = In.readDouble();
                    println(nv[index].PxPrint(d));
                    break;
                case '2':
                    print("P(X>x) for x = ");
                    double d2 = In.readDouble();
                    println(nv[index].GRPxPrint(d2));
                    break;
                case '3':
                    print("P(X=x) for x = ");
                    double d3 = In.readDouble();
                    println("P(X=" + d3 +") = 0.000");
                    println(nv[index].toString());
                    println("P(X=" + d3 +") = 0.000");
                    break;
                case '4':
                    print("D(x) for x = ");
                    double d4 = In.readDouble();
                    println(nv[index].DxPrint(d4));
                    break;
                case '5':
                    println("please note that this operation is particularly inacurate ;)");
                    print("P(X<x) = ");
                    double d5 = In.readDouble();
                    d5 = d5 < 1?d5:d5/100;
                    println(nv[index].invPxPrint(d5));
                    break;
                case '6':
                    println("please note that this operation is particularly inacurate ;)");
                    print("P(X<x) = ");
                    double d6 = In.readDouble();
                    d6 = d6 < 1?d6:d6/100;
                    println(nv[index].invDxPrint(d6));
                    break;
                case '7':
                    done = true;
                    createNormal();
                    break;
                default:
                    done = true;
                    break;
            }
        }
    }
    public static void println(String str){
        System.out.println(str);
    }
    public static void print(String str){
        System.out.print(str);
    }
    public static void tests2(){
        BinomialVerteilung bv = new BinomialVerteilung(500, 0.05);
        System.out.println(bv.getN() + ", "+ bv.getP());
        System.out.println(bv.toString());
        for (int i = 0; i < 20; i++) {
            System.out.println(bv.Peq(i));
        }
        boolean t = true;
        while(t){

        }
        NormalVerteilung nv = new NormalVerteilung(100, 10);
        System.out.println(nv.invertDx(0.10));
        System.out.println(Table.invertD(0.10));
    }
    public static void Tests(){
        System.out.println("Hello, World!");
        Table.test();
        NormalVerteilung nv01 = new NormalVerteilung(100, 10);
        System.out.println(nv01.Px(90)); //expected 0,159
        System.out.println(nv01.toString());
        System.out.println(nv01.PxPrint(120.0));
        ColorNormalVerteilung cnv01 = new ColorNormalVerteilung(nv01);
        System.out.println(cnv01.toString());
        System.out.println(cnv01.PxPrint(90.0));
    }
}
