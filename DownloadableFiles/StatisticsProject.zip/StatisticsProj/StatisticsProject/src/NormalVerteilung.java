import Support.Table;

public class NormalVerteilung {
    private double my, standardDeviation;
    static String ANSI_RES = "\u001B[0m", ANSI_RED = "\u001B[31m";
    public static boolean colorInput = true;
    static int resH = -1, resW = -1;

    public NormalVerteilung(double my, double standardDeviation){
        this.my = my;
        this.standardDeviation = standardDeviation==0?1:standardDeviation;
    }
    public static void setRes(int w, int h){
        resH = h; resW = w;
    }
    public static void setColor(boolean color){
        ANSI_RES = color?"\u001B[0m":"";
        ANSI_RED =color?"\u001B[31m":"";
    }
    public double invertPx(double p){
        double zOutP = Table.accInvertPsi(p);
        //z = x-my / SD |*SD |+my
        return (zOutP*standardDeviation) +my;
    }
    public double invertDx(double p){
        double zOutP = Table.accInvertD(p);
        //z = x-my / SD |*SD |+my
        return (zOutP*standardDeviation) +my;
    }
    public double getMy(){
        return round3(my);
    }
    public double getStandardDeviation(){
        return round3(standardDeviation);
    }
    public double Px(double x){
        return Table.psi(z(x));
    }
    public String invDxPrint(double p){
        //101 - 100 = 1
        double inv = round3(invertDx(p));
        String str = "D(" + ANSI_RED + "x" + ANSI_RES + ") = " + p +" = "+ round3(p*100) + "%\n--> "+ANSI_RED +"x"+ANSI_RES +" = " + (inv-my)+
            "-> P(" + (inv-my) + "<X<"+(my+inv)+") = " +  p  + " = " + round3(p*100) + "%";
        str += "\n";
        str += toStringD(120, 20, (inv-my), true, false);
        str += "\n" + "D(" + ANSI_RED + "x" + ANSI_RES + ") = " + p +" = "+ round3(p*100) + "%\n--> "+ANSI_RED +"x"+ANSI_RES +" = " + inv+
            "-> P(" + (my -(inv - my)) + "<X<"+(inv)+") = " +  p  + " = " + round3(p*100) + "%";
        return str;
    }
    public String invPxPrint(double p){
        double inv = round3(invertPx(p));
        String str = "P(X<" + ANSI_RED + "x" + ANSI_RES + ") = " + p +" = "+ round3(p*100) + "% --> "+ANSI_RED +"x"+ANSI_RES +" = " + inv;
        str += "\n";
        str += toStringWPara(120, 20, inv, true, false);
        str += "\n" + "P(X<" + ANSI_RED + "x" + ANSI_RES + ") = " + p +" = "+ round3(p*100) + "% --> "+ANSI_RED +"x"+ANSI_RES +" = " + inv;
        return str;
    }
    public String PxPrint(double x){
        String str = "P(X<" + x +") = " + Table.psi(z(x));
        str += "\n";
        str += toStringWPara(120, 20, x, true, false);
        str += "\n" + "P(X<" + x +") = " + Table.psi(z(x));
        return str;
    }
    public String GRPxPrint(double x){
        String str = "P(X>" + x +") = " + round3(1 - Table.psi(z(x)));
        str += "\n";
        str += toStringWPara(120, 20, x, true, true);
        str += "\n" + "P(X>" + x +") = " + round3(1-Table.psi(z(x)));
        return str;
    }
    public String DxPrint(double x){
        String str = "D(" + x +") = P(X<my + " + x + ") - P(X<my - " + x + ") = " + Dx(x);
        str += "\n";
        str += toStringD(120, 20, x, true, false);
        str += "\n" + "D(" + x +") = P(X<my + " + x + ") - P(X<my - " + x + ") = " + Dx(x);
        return str;
    }
    public double Dx(double x){
        //System.out.println(z(x));
        //mag nicht, also!
        double d1 = Table.accPsi(z(my+x));
        double d2 = Table.accPsi(z(my-x));
        double diff = d1>d2?d1-d2:d2-d1;
        return round3(diff);
        //return Table.D(z(x),0.01);
    }
    public double dichteX(double x){
        return Table.dichte(z(x));
    }
    public String toString(){
        return toStringWPara(120, 20, -1, false, false);
    }
    public String toStringD(int wIn, int hIn, double x, boolean show, boolean flip){
        int width = resW != -1 ? resW:120;
        int height = resH!= -1 ?resH:20;
        double[] dValues = new double[width];
        //first we get the bounds of the equivalent of z = -3 to z = 3
        // z = (x-my)/sD -> -3 = (?-my)/sD |*sD |+my --> -3*sD + my = x;
        double startX = (-3*standardDeviation) + my;
        double endX = (3*standardDeviation) +my;
        for (int i = 0; i < dValues.length; i++) {
            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            dValues[i] = dichteX(currX);
        }
        //from -3 to 3, steps of 0.2 --> 30 rows, 10 collums
        //then we get maximum dValue, can only be > 0
        double maxD = -1;
        for (int i = 0; i < dValues.length; i++) {
            if(dValues[i] >= maxD){
                maxD = dValues[i];
            }
        }
        double upperDiagr = round3(maxD);
        double middleDiagr = round3(maxD/2);
        //binary matrix!
        double xCut1 = show?my+x:startX-1;
        double xCut2 = show?my-x:endX+1;
        int[][] bValues = new int[height][width];
        for (int i = 0; i < width; i++) {

            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            int value = (currX < xCut1 && currX > xCut2) ? 2 : 1;

            int h = (int) Math.round((dValues[i] / maxD) * (double)(height - 1));
            for (int j = height -1; j >=  height-1-h; j--) {
                bValues[j][i] = value;
            }   
        }
        //now really toString!
        String str = "";
        for (int i = 0; i < bValues.length; i++) {
            if(i == 0){
                str += upperDiagr + "|"; //123_|
            }else{
                if(i == height/2){
                    str += middleDiagr + "|";
                }else{
                    if(i == height-1){
                        str += "0.000" + "|";
                    }
                    else{
                        str += "     |";
                    }
                }
            }
            for (int j = 0; j < bValues[i].length; j++) {
                if(bValues[i][j] == 1){
                    str += flip?(ANSI_RED + "#" + ANSI_RES):("*");
                }else{
                    if(bValues[i][j] == 2){
                        str+=flip?("*"):(ANSI_RED + "#" + ANSI_RES);
                    }else{
                        str+=" ";
                    }
                }
            }
            str+="\n";
        }
        str += "     |";
        for (int i = 0; i <= bValues[0].length; i++) {
            str+="-";
        }
        str += "\n      ";
        //0.000
        str+=round3(startX);
        int lI = 0;
        for (int i = 4; i < bValues[0].length/2-2; i++) {
            str += " ";
            lI = i;
        }
        str +=round3(my);
        for (int i = lI+6; i < bValues[0].length-4; i++) {
            str += " ";
        }
        str += round3(endX);
        return str;
    }
    public String toStringWPara(int wIn, int hIn, double x, boolean show, boolean flip){
        int width = resW != -1 ? resW:120;
        int height = resH!= -1 ?resH:20;
        double[] dValues = new double[width];
        //first we get the bounds of the equivalent of z = -3 to z = 3
        // z = (x-my)/sD -> -3 = (?-my)/sD |*sD |+my --> -3*sD + my = x;
        double startX = (-3*standardDeviation) + my;
        double endX = (3*standardDeviation) +my;
        for (int i = 0; i < dValues.length; i++) {
            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            dValues[i] = dichteX(currX);
        }
        //from -3 to 3, steps of 0.2 --> 30 rows, 10 collums
        //then we get maximum dValue, can only be > 0
        double maxD = -1;
        for (int i = 0; i < dValues.length; i++) {
            if(dValues[i] >= maxD){
                maxD = dValues[i];
            }
        }
        double upperDiagr = round3(maxD);
        double middleDiagr = round3(maxD/2);
        //binary matrix!
        double xCut = show?x:startX-1;
        int[][] bValues = new int[height][width];
        for (int i = 0; i < width; i++) {

            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            int value = currX < xCut ? 2 : 1;

            int h = (int) Math.round((dValues[i] / maxD) * (double)(height - 1));
            for (int j = height -1; j >=  height-1-h; j--) {
                bValues[j][i] = value;
            }   
        }
        //now really toString!
        String str = "";
        for (int i = 0; i < bValues.length; i++) {
            if(i == 0){
                str += upperDiagr + "|"; //123_|
            }else{
                if(i == height/2){
                    str += middleDiagr + "|";
                }else{
                    if(i == height-1){
                        str += "0.000" + "|";
                    }
                    else{
                        str += "     |";
                    }
                }
            }
            for (int j = 0; j < bValues[i].length; j++) {
                if(bValues[i][j] == 1){
                    str += flip?(ANSI_RED + "#" + ANSI_RES):("*");
                }else{
                    if(bValues[i][j] == 2){
                        str+=flip?("*"):(ANSI_RED + "#" + ANSI_RES);
                    }else{
                        str+=" ";
                    }
                }
            }
            str+="\n";
        }
        str += "     |";
        for (int i = 0; i <= bValues[0].length; i++) {
            str+="-";
        }
        str += "\n      ";
        //0.000
        str+=round3(startX);
        int lI = 0;
        for (int i = 4; i < bValues[0].length/2-2; i++) {
            str += " ";
            lI = i;
        }
        str +=round3(my);
        for (int i = lI+6; i < bValues[0].length-4; i++) {
            str += " ";
        }
        str += round3(endX);
        return str;
    }
    double z(double x){
        return (x - my) / standardDeviation;
    }
    double round3(double d){
        return Math.round(d * 1000.0)/1000.0;
    }
}
class ColorNormalVerteilung extends NormalVerteilung{
    public ColorNormalVerteilung(double my, double standardDeviation){
        super(my, standardDeviation);
    }
    public ColorNormalVerteilung(NormalVerteilung nv){
        super(nv == null?0:nv.getMy(), nv==null?1:nv.getStandardDeviation());
    }
    public String PxPrint(Double x){
        String str = "P(X<" + x +") = " + Table.psi(z(x));
        str += "\n";
        str += toStringWPara(120, 20, x, true);
        str += "\n" + "P(X<" + x +") = " + Table.psi(z(x));
        return str;
    }
    public String toString(){
        return toStringWPara(120, 20, -1, false);
    }
    public String toStringWPara(int wIn, int hIn, double x, boolean show){
        int width = resW != -1 ? resW:120;
        int height = resH!= -1 ?resH:20;
        double[] dValues = new double[width];
        //first we get the bounds of the equivalent of z = -3 to z = 3
        // z = (x-my)/sD -> -3 = (?-my)/sD |*sD |+my --> -3*sD + my = x;
        double startX = (-3*super.getStandardDeviation()) + super.getMy();
        double endX = (3*super.getStandardDeviation()) +super.getMy();
        for (int i = 0; i < dValues.length; i++) {
            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            dValues[i] = dichteX(currX);
        }
        //from -3 to 3, steps of 0.2 --> 30 rows, 10 collums
        //then we get maximum dValue, can only be > 0
        double maxD = -1;
        for (int i = 0; i < dValues.length; i++) {
            if(dValues[i] >= maxD){
                maxD = dValues[i];
            }
        }
        double upperDiagr = round3(maxD);
        double middleDiagr = round3(maxD/2);
        //binary matrix!
        double xCut = show?x:startX-1;
        int[][] bValues = new int[height][width];
        for (int i = 0; i < width; i++) {

            double currX = startX + (double)i * (endX-startX) / (double)(width-1);
            int value = currX < xCut ? 2 : 1;

            int h = (int) Math.round((dValues[i] / maxD) * (double)(height - 1));
            for (int j = height -1; j >=  height-1-h; j--) {
                bValues[j][i] = value;
            }   
        }
        //now really toString!
        String str = "";
        for (int i = 0; i < bValues.length; i++) {
            if(i == 0){
                str += upperDiagr + "|"; //123_|
            }else{
                if(i == height/2){
                    str += middleDiagr + "|";
                }else{
                    if(i == height-1){
                        str += "0.000" + "|";
                    }
                    else{
                        str += "     |";
                    }
                }
            }
            for (int j = 0; j < bValues[i].length; j++) {
                if(bValues[i][j] == 1){
                    str += "*";
                }else{
                    if(bValues[i][j] == 2){
                        str+="\u001B[31m" + "+" + "\u001B[0m"; //red
                    }else{
                        str+=" ";
                    }
                }
            }
            str+="\n";
        }
        str += "     |";
        for (int i = 0; i <= bValues[0].length; i++) {
            str+="-";
        }
        str += "\n      ";
        //0.000
        str+=round3(startX);
        int lI = 0;
        for (int i = 4; i < bValues[0].length/2-2; i++) {
            str += " ";
            lI = i;
        }
        str +=round3(super.getMy());
        for (int i = lI+6; i < bValues[0].length-4; i++) {
            str += " ";
        }
        str += round3(endX);
        return str;
    }
}
