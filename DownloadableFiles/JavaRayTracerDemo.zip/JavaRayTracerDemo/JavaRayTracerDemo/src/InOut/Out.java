package InOut;

public class Out {
    public static final String ANSI_RESET = /*"\u001B[0m";*/ "";
    public static String[] colors = {"\u001B[31m", "\u001B[32m", "\u001B[33m", "\u001B[34m", "\u001B[35m", "\u001B[36m", "\u001B[37m"};
    public static String currColor = ANSI_RESET;
    public static void updateColor(){
        return;
        /*Random rand = new Random();
        // Obtain a number between [0 - 49].
        int n = rand.nextInt(100);
        n++;
        if( n < 27){
            currColor = ANSI_RESET;
        }else{
            if(n<40){
                currColor = colors[0];
            }else{
                if(n < 50){
                    currColor = colors[1];
                }else{
                    if(n < 65){
                        currColor = colors[2];
                    }else{
                        if(n < 80){
                            currColor = colors[3];
                        }else{
                            if(n < 90){
                                currColor = colors[4];
                            }else{
                                currColor = colors[5];
                            }
                        }
                    }
                }
            }
        }*/
    }
    public static void print(String str){
        updateColor();
        System.out.print(currColor + str + ANSI_RESET);
    }
    public static void print(char str){
        updateColor();

        System.out.print(currColor + str+ ANSI_RESET);
    }
    public static void print(int str){
        updateColor();

        System.out.print(currColor + str+ ANSI_RESET);
    }
    public static void println(String str) throws InterruptedException{
        updateColor();

        System.out.println(currColor + str+ ANSI_RESET);
        Thread.sleep(10);
    }
    public static void println(String str, long time) throws InterruptedException{
        updateColor();

        //coolen fx jetzt
        for (int i = 0; i < str.length(); i++) {
            if(time == 0){
                if(i % 2 == 0)
                    Thread.sleep(1);
            }else{
                    Thread.sleep(time);
            }
            System.out.print(currColor + str.charAt(i));
        }
        System.out.println(ANSI_RESET);
    }
    public static void println(char str){
        updateColor();

        System.out.println(currColor + str +  ANSI_RESET);
    }
    public static void println(int str){
        updateColor();

        System.out.println(currColor + str + ANSI_RESET);
    }
}
