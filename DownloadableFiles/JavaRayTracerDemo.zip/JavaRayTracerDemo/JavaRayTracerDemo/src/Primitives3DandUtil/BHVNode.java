package Primitives3DandUtil;

public class BHVNode {
    public AABB box;
    public BHVNode left, right;
    public Triangle[] tris;
    private boolean forsphere = false;

    public boolean isLeaf() {
        return tris != null;
    }
    public void isForSphere(){
        this.forsphere = true;
    }
    public boolean forSphere(){
        return forsphere;
    }
}
