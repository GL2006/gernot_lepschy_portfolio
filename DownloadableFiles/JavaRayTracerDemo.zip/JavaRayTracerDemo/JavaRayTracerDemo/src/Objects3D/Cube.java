package Objects3D;

import Primitives3DandUtil.*;
import Primitives3DandUtil.Color.SurfaceType;
import SceneObjects.Camera;

public class Cube extends Object3D{
    private float a,b,h;
    private Face[] faces = new Face[6];
    private Vector3[] localVs = new Vector3[8]; 
    Triangle[] cachedTris;
    public Cube(Vector3 origin, double a, double b, double h){
        super(origin);
        this.a = (float)a; //pos a means +x
        this.b = (float)b; //pos b means +z
        this.h = (float)h*0.5f; //pos h means +y
        super.setColor(Color.WHITE());
        initialVerts();
        makeFaces();
    }
    public static Cube createColorCube(Vector3 origin, double a, double b, double h, Color color){
        Cube c1 =  new Cube(origin, a, b, h);
        c1.setColor(color);
        return c1;
    }
    public Vector3 getOrigin() {return origin;}
    public float getA() {return a;}
    public float getB() {return b;}
    public float getH() {return h;}
    public void RotX(int amount){
        Vector3 c = getCenter();
        double a = Math.toRadians(amount);
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        for(int i=0;i<localVs.length;i++){
            Vector3 v = localVs[i].subtract(c);
            double y = v.getY()*cos - v.getZ()*sin;
            double z = v.getY()*sin + v.getZ()*cos;
            localVs[i] = new Vector3(v.getX(), y, z).add(c);
        }
        makeFaces();
        Camera.recacheObj = this;
    }
    public void RotY(int amount){
        Vector3 c = getCenter();
        double a = Math.toRadians(amount);
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        for(int i=0;i<localVs.length;i++){
            Vector3 v = localVs[i].subtract(c);
            double x =  v.getX()*cos + v.getZ()*sin;
            double z = -v.getX()*sin + v.getZ()*cos;
            localVs[i] = new Vector3(x, v.getY(), z).add(c);
        }
        makeFaces();
        Camera.recacheObj = this;
    }
    public void RotZ(int amount){
        Vector3 c = getCenter();
        double a = Math.toRadians(amount);
        double cos = Math.cos(a);
        double sin = Math.sin(a);
        for(int i=0;i<localVs.length;i++){
            Vector3 v = localVs[i].subtract(c);
            double x = v.getX()*cos - v.getY()*sin;
            double y = v.getX()*sin + v.getY()*cos;
            localVs[i] = new Vector3(x, y, v.getZ()).add(c);
        }
        makeFaces();
        Camera.recacheObj = this;
    }
    private Vector3 getCenter(){
        double cx = 0, cy = 0, cz = 0;
        for(Vector3 v : localVs){
            cx += v.getX();
            cy += v.getY();
            cz += v.getZ();
        }
        return new Vector3(
            cx / localVs.length,
            cy / localVs.length,
            cz / localVs.length
        );
    }
    public void scaleX(float amount){
        this.a *= amount;
        makeFaces();
        Camera.recacheObj = this;

    }
    public void scaleY(float amount){
        this.h *= amount;
        makeFaces();
        Camera.recacheObj = this;

    }
    public void scaleZ(float amount){
        this.b *= amount;
        makeFaces();
        Camera.recacheObj = this;

    }
    public void scaleXYZ(float amount){
        this.a *= amount; this.b *=amount; this.h *= amount;
        makeFaces();
    }
    public Face[] getFaces(){
        return faces;
    }
    private void cacheTris(){
        Triangle[] tris = new Triangle[faces.length * 2];
        int triIndex = 0;
        for (int i = 0; i < faces.length; i++) {
            tris[triIndex] = faces[i].getTris()[0];
            tris[triIndex+1] = faces[i].getTris()[1];
            triIndex+=2; 
        }
        cachedTris = tris;
    }
    public Triangle[] getTris(){  
        return cachedTris;
    }
    private void makeFaces(){
        //Vector3[] verts = getVerts();
        //faces then
        // bottom (-Y)
        faces[0] = new Face(localVs[0], localVs[1], localVs[2], localVs[3], this);
        // top (+Y)
        faces[1] = new Face(localVs[4], localVs[7], localVs[6], localVs[5], this);
        // left (-X)
        faces[2] = new Face(localVs[0], localVs[3], localVs[7], localVs[4], this);
        // right (+X)
        faces[3] = new Face(localVs[1], localVs[5], localVs[6], localVs[2], this);
        // back (+Z)
        faces[4] = new Face(localVs[3], localVs[2], localVs[6], localVs[7], this);
        // front (-Z)
        faces[5] = new Face(localVs[0], localVs[4], localVs[5], localVs[1], this);
        //getting min and max
        float[] vX = new float[8];
        float[] vY = new float[8];
        float[] vZ = new float[8];
        for (int i = 0; i < localVs.length; i++) {
            vX[i] = (float)localVs[i].getX();
            vY[i] = (float)localVs[i].getY();
            vZ[i] = (float)localVs[i].getZ();
        }
        double[] tV1 = {getMin(vX), getMin(vY), getMin(vZ)}; 
        double[] tV2 = {getMax(vX), getMax(vY), getMax(vZ)}; 
        super.boundingBox = new AABB(new Vector3(tV1), new Vector3(tV2));
        cacheTris();
    }
    public void initialVerts(){
       // Vector3[] verts = new Vector3[8];
        //down
        localVs[0] = this.origin;
        localVs[1] = localVs[0].add(new Vector3(this.a, 0, 0));
        localVs[2] = localVs[1].add(new Vector3(0,0, this.b));
        localVs[3] = localVs[0].add(new Vector3(0,0, this.b)); 
        //up
        localVs[4] = localVs[0].add(new Vector3(0, this.h, 0));
        localVs[5] = localVs[1].add(new Vector3(0, this.h, 0));
        localVs[6] = localVs[2].add(new Vector3(0, this.h, 0));
        localVs[7] = localVs[3].add(new Vector3(0, this.h, 0));
       // return verts;
    }
    public static float getMin(float[] ints){
        float min = ints[0];
        for (int i = 0; i < ints.length; i++) {
            min = ints[i] < min?ints[i]:min;
        }
        return min;
    }
    public static float getMax(float[] ints){
        float max = ints[0];
        for (int i = 0; i < ints.length; i++) {
            max = ints[i] > max?ints[i]:max;
        }
        return max;
    }
    public int numberOfTris() {
        return faces.length * 2;
    }
}
