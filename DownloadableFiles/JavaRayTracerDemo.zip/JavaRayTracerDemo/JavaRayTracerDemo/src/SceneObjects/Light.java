package SceneObjects;

import Primitives3DandUtil.*;

public class Light {
    private Vector3 position;
    private Color color;
    private double intensity;
    private int r,g,b;
    public Light(Vector3 position, Color color, double intensity){
        if(position==null||color==null||intensity<0) return;
        this.position = position;
        this.color = color;
        this.intensity = intensity;
        setRGB();
    }
    private void setRGB(){
        r = color.getR_FAST(); g = color.getG_FAST(); b = color.getB_FAST();
    }
    public Vector3 getPosition() { return this.position; }
    public Color getColor() { return this.color; }
    public void setColor(Color c) { this.color = c; }
    public double getIntensity() { return this.intensity; }
    public int R(){return r;}
    public int G(){return g;}
    public int B(){return b;}
    public void setPosition(Vector3 pos){
        this.position = pos==null?this.position:pos;
    }

}
