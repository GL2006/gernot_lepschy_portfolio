package Primitives3DandUtil;

import Objects3D.Object3D;
import Primitives3DandUtil.Color.SurfaceType;

public class Face {
    public Vector3[] points = new Vector3[4];
    private Triangle[] triangles= new Triangle[2];
    private Object3D owner;
    
    public Face(Vector3 point1, Vector3 point2, Vector3 point3, Vector3 point4, Object3D owner){
        if(point1==null||point2==null||point3==null||point3==null) return;
        this.points[0] = point1; this.points[1] = point2; this.points[2] = point3; this.points[3] = point4;
        this.owner = owner;
        makeTris();
    }
    public Face(Vector3[] points, Object3D owner){
        if(points==null) return;
        if(points.length != 4) return;
        this.points = points;
        this.owner = owner;
        makeTris();
    }
    private void makeTris(){
        triangles[0] = new Triangle(points[0],points[1], points[2]);
        triangles[0].setOwner(owner);
        triangles[1] = new Triangle(points[0], points[2], points[3]);
        triangles[1].setOwner(owner);
    }
    public Triangle[] getTris(){return this.triangles;}
    public boolean isReflective() {
        return owner.isReflective();
    }
}
