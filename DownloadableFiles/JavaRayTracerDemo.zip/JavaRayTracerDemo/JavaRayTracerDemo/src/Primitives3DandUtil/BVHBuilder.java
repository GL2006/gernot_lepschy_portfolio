package Primitives3DandUtil;

import java.util.Arrays;
import java.util.Comparator;

import Objects3D.ImportedObject3D;

public class BVHBuilder {
private static final int LEAF_SIZE = 4;

    public static BHVNode build(Triangle[] tris) {
        BHVNode node = new BHVNode();

        node.box = AABB.fromTriangles(tris);
        
        if (tris.length <= LEAF_SIZE) {
            node.tris = tris;
            setSphereFlag(node);
            return node;
        }

        // längste Achse
        Vector3 size = node.box.getSize();
        int axis = size.getX() > size.getY()? (size.getX() > size.getZ() ? 0 : 2): (size.getY() > size.getZ() ? 1 : 2);

        Arrays.sort(tris, Comparator.comparingDouble(t -> t.getCenterV().get(axis)));

        int mid = tris.length / 2;

        node.left = build(Arrays.copyOfRange(tris, 0, mid));
        node.right = build(Arrays.copyOfRange(tris, mid, tris.length));
        if (node.left != null && node.left.forSphere()) {
            node.isForSphere();
        }
        if (node.right != null && node.right.forSphere()) {
            node.isForSphere();
        }
        return node;
    }
    private static void setSphereFlag(BHVNode node) {
        if (node.tris != null) {
            // Prüfe ob mindestens ein Triangle ein SphereTri ist
            for (Triangle tri : node.tris) {
                if (tri instanceof SphereTri/* || tri.getOwner() instanceof ImportedObject3D*/) {
                    node.isForSphere();
                    return;
                }
            }
        }
    }
}
