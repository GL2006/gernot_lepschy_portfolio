import InOut.*;
import Objects3D.*;
import Primitives3DandUtil.*;
import Primitives3DandUtil.Color.SurfaceType;
import SceneObjects.*;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        TESTRENDER();
        /*
         * char c = ' ';
         * while(c != 'n'){
         * c = In.readChar();
         * if(c == 'w'){
         * cam.changePos(cam.getPos().add(new Vector3(0,0,1)));
         * }
         * if(c == 's'){
         * cam.changePos(cam.getPos().add(new Vector3(0,0,-1)));
         * }
         * Out.println(cam.ASCIIrender(80, 24));
         * }
         */
    }
    static void TESTRENDERIII(){
        ImportedObject3D testObj = new ImportedObject3D(new Vector3(-235, -10, 10),
                "C:\\Users\\dleps\\Downloads\\testobjs\\cityII.obj");
       //testObj.RotX(-90);
       testObj.setColor(Color.WHITE());
       testObj.MATT();
       testObj.scale(.02f);
        testObj.RotY(270);
       // testObj.RotY(90);
        Light l1 = new Light(new Vector3(3,2, 5), Color.WHITE(), 100.0);
        Sphere s1 = new Sphere(new Vector3(2, 0, 10), 0.5f);
        s1.setColor(Color.BLUE());
        s1.MATT();
        s1.setSurfaceType(0.3f);
        Vector3 camPos = testObj.getCenter().subtract(new Vector3(-0.7,0, 10));
        Object3D[] objects = new Object3D[]{testObj, s1};
        Light[] lights = new Light[]{l1};
        s1.move(camPos.add(new Vector3(-0.5, 0, 4)));
        Camera cam = new Camera(new Vector3(230, 700, -610), new Vector3(0, 0, 1),
                objects,
                lights, new Color(68, 142, 225));
        cam.ambient = 1e-10f;
        cam.changePos(camPos);
        //cam.changePos(cam.getPos().add(new Vector3(10, 0, 90)));
        //cam.rotate(90);
        l1.setPosition(cam.getPos().subtract(new Vector3(0, 10, 5)));
        cam.maxDist = 100;
        //cam.renderWireframe(444, 444);
        //cam.efficientRender(1920, 1080, 1);
        for (int i = 0; i < 100; i++) {
            testObj.RotY((int)(360f/100f));
          //  cam.renderWireframe(1920, 1080);
            cam.efficientRender(1920, 1080, 1.2, i+1);
        }
       // camMove(cam);
    }
    static void TESTRENDERII(){
        ImportedObject3D Obj = new ImportedObject3D(new Vector3(0, 0, -1),
                "C:\\Users\\dleps\\Downloads\\testobjs\\corrido2r.obj");
       // testObj.RotX(-90);
        Obj.RotY(90);
       // testObj.RotY(90);
        Light l1 = new Light(new Vector3(3,2, -495), Color.WHITE(), 1.0);
        Sphere s1 = new Sphere(new Vector3(2, 0, -490), 1);
        s1.setColor(Color.BLUE());
        s1.MIRROR();
        s1.setSurfaceType(0.9f);
        Object3D[] objects = new Object3D[]{Obj, s1};
        Light[] lights = new Light[]{l1};
        Camera cam = new Camera(new Vector3(2, 0, -500), new Vector3(0, 0, 1),
                objects,
                lights, new Color(68, 142, 225));
        //cam.maxDist = 100;
        int rendT = 2;
        Obj.setColor(new Color(10, 10, 10));
        int r, g,b; r = b = g = 10;  int r2, g2,b2; r2 =68; g2 = 142; b2 = 225; 
        for (int i = 0; i < 200; i++) {
            switch (rendT) {
                case 0:
                    cam.renderWireframe(500, 290);
                    break;
                case 1:
                    cam.DephtImageRender(400, 300);
                    break;
                default:
                    cam.efficientRender(1600, 900, 1.2, i+1); //900p
                    break;
            }
            if(i < 50){
                r+= 5;
                r2 += 5;
                g2--;
                b2 -= 6;
                Obj.MATT();
            }else{
                if(i < 100){
                    g += 5;
                    g2++;
                    r--;
                    b2++;
                    Obj.METAL();
                }else{
                    if (i < 150) {
                        r2++;
                        b2++;
                        g2++;
                        b += 5;
                        Obj.PLASTIC();
                    }else{
                         r2-=10;
                        b2-=10;
                        g2-=10;
                        Obj.METAL();
                        r -= 5;
                        b -= 5;
                        g -= 5;
                    }
                }
            }  
            cam.skyColor = new Color(r2, g2, b2).clamp();
            Obj.setColor(new Color(r, g, b));
            cam.changePos(cam.getPos().add(new Vector3(0, 0, (500f/200f))));
            s1.move(cam.getPos().add(new Vector3(0, 0, 10)));
            l1.setPosition(cam.getPos().add(new Vector3(0, 0, 5)));
        }
       // cam.DephtImageRender(1920, 1080);
    }
    static void camMove(Camera cam){
         char c = ' ';
        while(c != 'n'){
         c = In.readChar();
         if(c == 'w'){
         cam.changePos(cam.getPos().add(new Vector3(0,1,0)));
         }
         if(c == 's'){
         cam.changePos(cam.getPos().add(new Vector3(0,-1,0)));
         }
         if(c == 'd'){
         cam.changePos(cam.getPos().add(new Vector3(-1,0,0)));
         }
         if(c == 'a'){
         cam.changePos(cam.getPos().add(new Vector3(1,0,0)));
         }
         if(c == 'p')
            System.out.println("pos" + cam.getPos());
        TestImage.number = -100;
        cam.renderWireframe(500, 290);
         }
    }
    static void TESTRENDER() {
        // Cubes
        Cube c1 = new Cube(new Vector3(-2, 0, 0), 1, 1, 1);
        // c1.RotY(0);
        c1.setColor(Color.RED());
        c1.MATT();
        Cube c2 = new Cube(new Vector3(2, 0, 0), 1, 1, 1);
        Cube c3 = new Cube(new Vector3(-2, 0, 1.5), 1, 1, 1);
        Cube c4 = new Cube(new Vector3(2, 0, 1.5), 1, 1, 1);
        c4.setColor(Color.RED());
        Cube c5 = new Cube(new Vector3(2, 0, 3), 1, 1, 1);
        Cube c6 = new Cube(new Vector3(-2, 0, 3), 1, 1, 1);
        c6.setColor(Color.RED());
        Cube c7 = new Cube(new Vector3(2, 0, 4.5), 1, 1, 1);
        c7.setColor(Color.RED());
        Cube c8 = new Cube(new Vector3(-2, 0, 4.5), 1, 1, 1);
        Cube floor = new Cube(new Vector3(-10, -0.05, -3), 20, 20, 0.1);
        Cube rotCube = new Cube(new Vector3(0.4, 0.1, 0.1), 0.25, 0.25, 0.5);
        rotCube.METAL();
        rotCube.setColor(new Color(5, 5, 5));
        rotCube.setSurfaceType(0.5f);
        rotCube.RotX(45);
        rotCube.RotZ(45);
        rotCube.RotY(45);
        // floor.setSurfaceType(SurfaceType.REFLECTIVE, 0.6f);
        floor.MIRROR();
        Sphere s = new Sphere(new Vector3(-0.5, 0.5, 2.5), 0.25);
        Sphere s2 = new Sphere(new Vector3(0.1, 0.3, 1.5), 0.3);
        s2.MIRROR();
        // s.setSurfaceType(SurfaceType.REFLECTIVE, 0.1f);
        Color reflBlue = new Color(10, 10, 10);
        ImportedObject3D testObj = new ImportedObject3D(new Vector3(-0.5, 0.15, 1.75),
                "C:\\Users\\dleps\\Downloads\\testobjs\\fighterjetRED.obj");
        testObj.scale(0.2);
        testObj.setColor(reflBlue);
        testObj.setSurfaceType(SurfaceType.REFLECTIVE, 0.3f);
        Triangle[] tris = c1.getTris();
        for (int i = 0; i < tris.length; i++) {
            System.out.println(tris[i].toString());
        }
        Light l1 = new Light(new Vector3(1.5, 1.5, 3.5), Color.WHITE(), 1.0);
        Light l2 = new Light(new Vector3(1, 1.5, 0), Color.WHITE(), 0.1);
        // renderobjs
        Object3D[] objects = new Object3D[] { c1, c2, c3, c4, c5, c6, c7, c8, s, testObj, s2, floor, rotCube };
        Light[] lights = new Light[] { l1, l2 };
        // Camera
        Camera cam = new Camera(new Vector3(0.5, 0.5, -1), new Vector3(0, 0, 1),
                objects,
                lights, new Color(68, 142, 225));
        Camera asciicam = new Camera(new Vector3(0.5, 0.5, 1), new Vector3(0, 0, 1), objects, null);

        System.out.println(asciicam.ASCIIrender(80, 24));
        // cam.DephtImageRender(1920, 1080);
        cam.maxDist = 20;
        cam.ambient = 0.0001e10f;
       // cam.renderWireframe(1920/10, 1080/10);
        cam.efficientRender(1920, 1080, 10);
       /// cam.SeperatedDephtColorImageRender(1920, 1080, 100);

        // return;
        // rotation anim::

        //for (int i = 1; i < 101; i++) {
      // rotCube.RotY((int) (360f / 100f));
        // cam.renderWireframe(1920, 1080);

        // cam.DephtImageRender(1920, 1080);
         //}

        // other anim

        /*for (int i = 0; i < 100; i++) {
            if (i <= 50) {
                Vector3 spherePos = s.getOrigin();
                double angle = 2.0 * Math.PI * i / 50;

                double lx = spherePos.getX() + Math.cos(angle) * 2;
                double ly = spherePos.getY() + 1.0;
                double lz = spherePos.getZ() + Math.sin(angle) * 2;

                Vector3 lightpos = new Vector3(lx, ly, lz);
                // Vector3 lightpos = //???
                l1.setPosition(lightpos);
                Vector3 temp = spherePos.subtract(lightpos);
                temp.setX(1.5);
                l2.setPosition(temp);
            } else {
                l1.setColor(new Color(3 * i, 1.4 * i, 1.5 * i).clamp());
                l1.setColor(new Color(1.5 * i, 1.3 * i, 3 * i).clamp());
                cam.changePos(cam.getPos().add(new Vector3(0, 0, 0.1)));
                cam.rotate(1);
            }
           // cam.imageRender(1920, 1080, i + 1);// (1920, 1080);
            cam.renderWireframe(1920, 1080);
        }*/

    }
    /*
     * for (int i = 0; i < 50; i++) {
     * Vector3 spherePos = s.getOrigin();
     * double angle = 2.0 * Math.PI * i / 50;
     * 
     * double lx = spherePos.getX() + Math.cos(angle) * 2;
     * double ly = spherePos.getY() + 1.0;
     * double lz = spherePos.getZ() + Math.sin(angle) * 2;
     * 
     * Vector3 lightpos = new Vector3(lx, ly, lz);
     * // Vector3 lightpos = //???
     * l1.setPosition(lightpos);
     * cam.imageRender(1920, 1080, i+1);//(1920, 1080);
     * }
     */
}
