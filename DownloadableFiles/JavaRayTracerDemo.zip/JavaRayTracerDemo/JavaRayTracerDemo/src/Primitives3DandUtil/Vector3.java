package Primitives3DandUtil;

public class Vector3 {
    private float x, y, z;
    public Vector3(double x, double y, double z){
        this.x = (float)x; this.y = (float)y; this.z = (float)z;
    }
    public Vector3(double[] array){
        if(array == null) return;
        if(array.length != 3) return;
        this.x = (float)array[0]; this.y = (float)array[1]; this.z = (float)array[2];
    }
    public static float dot(Vector3 a, Vector3 b) {
        return a.getX() * b.getX() + a.getY() * b.getY() + a.getZ() * b.getZ();
    }
    //floats
    public Vector3(float x, float y, float z){
        this.x = x; this.y = y; this.z = z;
    }
    public Vector3(float[] array){
        if(array == null) return;
        if(array.length != 3) return;
        this.x = array[0]; this.y = array[1]; this.z = array[2];
    }
    public float getX(){
        return x;
    }
    public float getY(){
        return y;
    }
    public float getZ(){
        return z;
    }
    public void setX(double x){
        this.x = (float)x;
    }
    public void setY(double y){
        this.y = (float)y;
    }
    public void setZ(double z){
        this.z = (float)z;
    }
    public float distance(Vector3 otherV){
        if(otherV == null){
            return -1;
        }
        float underSqrt, tX, tY, tZ;
        if(otherV.length() > this.length()){
            tX = otherV.getX() - this.x;
            tY = otherV.getY() - this.y;
            tZ = otherV.getZ() - this.z;
        }else{
            tX = this.x - otherV.getX();
            tY = this.y - otherV.getY();
            tZ = this.z - otherV.getZ();
        }
        underSqrt = tX*tX + tY*tY + tZ*tZ;
        return (float)Math.sqrt(underSqrt);
    }
    public Vector3 add(Vector3 otherV){
        return new Vector3(otherV == null?x:x+otherV.getX(), otherV==null?y:y+otherV.getY(), otherV==null?z:z+otherV.getZ());
    }
    public Vector3 subtract(Vector3 otherV){
        return new Vector3(otherV == null?x:x-otherV.getX(), otherV==null?y:y-otherV.getY(), otherV==null?z:z-otherV.getZ());

    }
    public Vector3 multiply(double d){
        return new Vector3(this.x * d, this.y*d, this.z*d);
    }
    public Vector3 divide(double d){
        return multiply((1.0/d));
    }
    public void changeTo(Vector3 otherV){
        if(otherV == null){
            return;
        }
        this.x = otherV.getX();
        this.y = otherV.getY();
        this.z = otherV.getZ();
    }
    public float fDot(Vector3 v2){
        if(v2 == null) return -1;
        float mX = (float)this.x * (float)v2.getX();
        float mY = (float)this.y * (float)v2.getY();
        float mZ = (float)this.z * (float)v2.getZ();
        return (mX+mY+mZ);
    }
    public double dot(Vector3 v2){
        return fDot(v2);
      /*   if(v2 == null) return -1;
        double mX = this.x * v2.getX();
        double mY = this.y * v2.getY();
        double mZ = this.z * v2.getZ();
        return (mX+mY+mZ);*/
    }
    public double length(){
        double underSqrt = x*x+y*y+z*z;
        return Math.sqrt(underSqrt);
    }
    double round2(double d){
        return Math.round(d * 100.0)/100.0;
    }
    float round2(float f){
        return (float)Math.round(f * 1000.0f)/1000.0f;
    }
    public String toString(){
        String str = "("+x+"/"+y+"/"+z+")";
        return str;
    }
    public Vector3 normalized(){
        double l = length();
        return new Vector3(this.x/l,this.y/l,this.z/l);
    }
    public void normalize(){
        double l = length();
        this.x /= l;
        this.y /=l;
        this.z /= l;
    }
    public void normalizeFloat(){
        float l = (float)length();
        this.x /= l;
        this.y /=l;
        this.z /= l;
    }
    public Vector3 inverted(){
        return new Vector3(-x, -y, -z);
    }
    public void invert(){
        this.x = -x;
        this.y = -y;
        this.z = -z;
    }
    public void rotate(double degrees){
        float rad = (float)Math.toRadians(degrees);
        float tempX = this.x; float tempY = this.y; float tempZ = this.z;
        //y is already okay, we only need to change x and z
        float nX = (float)Math.cos(rad) * tempX - (float)Math.sin(rad)*tempZ;
        float nZ = (float)Math.sin(rad) * tempX + (float)Math.cos(rad) * tempZ;

        this.x = nX;
        this.y = tempY;
        this.z = nZ;
    }
    //kreuzprodukt definition lt wikipedia
    public Vector3 cross(Vector3 otherV){
        float a1 = (float)this.x, b1 = (float)otherV.getX();
        float a2 = (float)this.y, b2 = (float)otherV.getY();
        float a3 = (float)this.z, b3 = (float)otherV.getZ();

        float tempX = a2*b3-a3*b2;
        float tempY = a3*b1-a1*b3;
        float tempZ = a1*b2-a2*b1;
        return new Vector3(tempX, tempY, tempZ);
    }
    public Vector3 moreAccurateCross(Vector3 otherV){
        double a1 = this.x, b1 = otherV.getX();
        double a2 = this.y, b2 = otherV.getY();
        double a3 = this.z, b3 = otherV.getZ();

        double tempX = a2*b3-a3*b2;
        double tempY = a3*b1-a1*b3;
        double tempZ = a1*b2-a2*b1;
        return new Vector3(tempX, tempY, tempZ);
    }
    public float get(int axis) {
        switch (axis) {
            case 0: return x;
            case 1: return y;
            case 2: return z;
            default: return 1f/0f;
        }
    }
    public Vector3 reflect(Vector3 normal) {
        // this = incoming direction
        float d = this.fDot(normal);
        return this.subtract(normal.multiply(2.0 * d));
    }
    public static Vector3 cross(Vector3 a, Vector3 b) {
        return new Vector3(
            a.getY() * b.getZ() - a.getZ() * b.getY(),
            a.getZ() * b.getX() - a.getX() * b.getZ(),
            a.getX() * b.getY() - a.getY() * b.getX()
        );
    }
    public static Vector3 sub(Vector3 a, Vector3 b){
        return new Vector3(
            a.getX() - b.getX(),
            a.getY() - b.getY(),
            a.getZ() - b.getZ()
        );
    }
    public static Vector3 plus(Vector3 a, Vector3 b){
        return new Vector3(
            a.getX() + b.getX(),
            a.getY() + b.getY(),
            a.getZ() + b.getZ()
        );
    }
    public static Vector3 mult(Vector3 a, float b){
        return new Vector3(
            a.getX() *b,
            a.getY() *b,
            a.getZ() *b
        );
    }
    public static boolean intersectTriangle(
        Vector3 orig, Vector3 dir,
        Vector3 v0, Vector3 v1, Vector3 v2,
        float[] result // [0]=t, [1]=u, [2]=v
    ) {
        Vector3 edge1 = sub(v1, v0);
        Vector3 edge2 = sub(v2, v0);
        Vector3 pvec = cross(dir, edge2);
        
        float det = dot(edge1, pvec);
        if (det > -1e-8 && det < 1e-8) return false;
        
        float invDet = 1.0f / det;
        Vector3 tvec = sub(orig, v0);
        
        float u = dot(tvec, pvec) * invDet;
        if (u < 0.0 || u > 1.0) return false;
        
        Vector3 qvec = cross(tvec, edge1);
        float v = dot(dir, qvec) * invDet;
        if (v < 0.0 || u + v > 1.0) return false;
        
        float t = dot(edge2, qvec) * invDet;
        if (t <= 1e-8) return false;
        
        result[0] = t; result[1] = u; result[2] = v;
        return true;
    }
}
