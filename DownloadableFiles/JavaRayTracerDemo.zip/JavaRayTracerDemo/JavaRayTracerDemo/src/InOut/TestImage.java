package InOut;

import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import Primitives3DandUtil.Color;

import java.awt.Desktop;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class TestImage {
    private static Color skyColor = Color.BLACK();
    private static boolean useBackgroundColor = false;
    public static int number = -1;
    public static void setSkyColor(Color c){
        useBackgroundColor = true; 
        skyColor = c;
    }
    public static void resetSkyColor(){
        useBackgroundColor = false; 
        skyColor = Color.BLACK();
    }
    public static void seperateDephtImg(double[][] matrix, int howmany, Color[][] color){
        howmany = howmany>0?howmany:1;
        double max = -2;
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix.length; j++) {
                max = matrix[i][j] > max && matrix[i][j] > 0?matrix[i][j]:max;
            }
        }
        double min = 1.0/0.0;
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix.length; j++) {
                min = matrix[i][j] < min && matrix[i][j] > 0?matrix[i][j]:min;
            }
        }
        double[][] matrix2 = new double[matrix.length][matrix[0].length];
        for (int i = 0; i < matrix2.length; i++) {
            for (int j = 0; j < matrix2.length; j++) {
                matrix2[i][j] = matrix[i][j]-min;
            }
        }
        max -= min;
        for (int i = 0; i < howmany; i++) {
            oneDephtImg(max, (double)i*max/(double)howmany, matrix, i+1, color);
        }
    }
    public static void seperateDephtImg(double[][] matrix, int howmany){
        seperateDephtImg(matrix, howmany, null);
    }
    private static void oneDephtImg(double max, double cutOff, double[][] matrix, int num, Color[][] colors){
        int height = matrix.length; int width = matrix[0].length;

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float dist = (float)matrix[y][x];
                    //number++;
                    //dephtimg
                    int gray = toGray(dist<cutOff?dist:1e10, max*1.7);
                    if(colors == null){
                        int rgb = (gray << 16) | (gray << 8) | gray;
                        image.setRGB(x, y, rgb);
                    }else{
                        if(colors[y][x] != null){
                            int rgb =  dist<cutOff?getShadedColor(colors[y][x], dist,30):(gray << 16) | (gray << 8) | gray;
                            image.setRGB(x, y, rgb);
                        }else{
                            int rgb = getShadedColor(skyColor, 0, 10);
                            image.setRGB(x, y, rgb);
                        }
                    }
            }
        }
        reallySave(image, "dephtNr" + num);
    }
    public static void saveImg(double[][] matrix, double maxDist, int i, Color[][] colors) {
        saveImg(matrix, maxDist, i, colors, 1, 1); //aa auf 1, also nix
    }
    public static void saveImg(double[][] matrix, double maxDist, int i, Color[][] colors, int aaLevel, double upscalFactor){//antialiasing lvl
        if(matrix == null) return; 
        //min res 10x10
        if(matrix.length < 10) return;
        if(matrix[0].length < 10) return;
        int height = matrix.length; int width = matrix[0].length;

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        if(i < 0){
            number ++;
        }
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                float dist = (float)matrix[y][x];
                if(i==-1){
                    //number++;
                    //dephtimg
                    int gray = toGray(dist, maxDist*1.7);
                    int rgb = (gray << 16) | (gray << 8) | gray;
                    image.setRGB(x, y, rgb);
                    continue;
                }else if(i==-2){ //wireframe
                  //  number++;
                    image.setRGB(x, y, (int)dist);
                    continue;
                }
                if(colors == null || colors[y][x] == null || colors[y][x].getR() < 0){
                    if(useBackgroundColor){
                            //Benutzerdefinierte Hintergrundfarbe
                            int rgb = getShadedColor(skyColor, 0, maxDist);
                            image.setRGB(x, y, rgb);
                    }else {
                        //Standard: Tiefen-Graustufen
                        int gray = toGray(dist, maxDist);
                        int rgb = (gray << 16) | (gray << 8) | gray;
                        image.setRGB(x, y, rgb);
                    }
                } else {
                    //Normales Objekt mit Farbe
                    int rgb = getShadedColor(colors[y][x], dist, maxDist);
                    image.setRGB(x, y, rgb);
                }
            }
        }
        if (aaLevel > 1) {
            image = applyAdaptiveAA(image, aaLevel);
        }
      //  if(Math.abs(upscalFactor-1)>0.01){
            image = upscaled(image, width, height, upscalFactor);
       // }
       //System.out.println(number + "N");
       String str = "";
       String formattedName;
       if(number > 0){
            formattedName = String.format("render%04d",  number);
            str =  number <1?"render":formattedName;
            reallySave(image, str);
            return;
       }
        formattedName = String.format("render%04d",  i);
        str =  i <1?"render":formattedName;
        reallySave(image, str);
        
    }
    private static BufferedImage upscaled(BufferedImage image, int width, int height, double factor){
        return upscaleJava2D(image, (int)(width*factor), (int)(height*factor));     
    }
    private static BufferedImage upscaleJava2D(BufferedImage src, int newWidth, int newHeight) {
        BufferedImage dest = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = dest.createGraphics();
        
        // HOCHWERTIGE INTERPOLATION EINSTELLEN
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, 
                            RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, 
                            RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                            RenderingHints.VALUE_ANTIALIAS_ON);
        
        // BILD HOCHSKALIEREN
        g2d.drawImage(src, 0, 0, newWidth, newHeight, null);
        g2d.dispose();
        
        return dest;
    }
    private static BufferedImage applyAdaptiveAA(BufferedImage img, int strength) {
        int width = img.getWidth();
        int height = img.getHeight();
        BufferedImage result = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        
        float threshold = 30.0f / strength; // Empfindlichkeit
        
        for (int y = 1; y < height - 1; y++) {
            for (int x = 1; x < width - 1; x++) {
                int center = img.getRGB(x, y);
                
                //Farbdiff berechnen
                int[] neighbors = {
                    img.getRGB(x-1, y), img.getRGB(x+1, y),
                    img.getRGB(x, y-1), img.getRGB(x, y+1)
                };
                
                float maxDiff = 0;
                for (int neighbor : neighbors) {
                    float diff = colorDifference(center, neighbor);
                    maxDiff = Math.max(maxDiff, diff);
                }
                
                //Wenn Kante, dann glaetten
                if (maxDiff > threshold) {
                    //3x3 Kernel Mittelung
                    int r = 0, g = 0, b = 0;
                    for (int ky = -1; ky <= 1; ky++) {
                        for (int kx = -1; kx <= 1; kx++) {
                            int rgb = img.getRGB(x + kx, y + ky);
                            r += (rgb >> 16) & 0xFF;
                            g += (rgb >> 8) & 0xFF;
                            b += rgb & 0xFF;
                        }
                    }
                    
                    r /= 9; g /= 9; b /= 9;
                    result.setRGB(x, y, (r << 16) | (g << 8) | b);
                } else {
                    result.setRGB(x, y, center);
                }
            }
        }
        
        // Ränder kopieren
        copyBorders(img, result);
        return result;
    }
    private static void copyBorders(BufferedImage src, BufferedImage dst) {
        int width = src.getWidth();
        int height = src.getHeight();
        
        //early return
        if (width != dst.getWidth() || height != dst.getHeight()) {
            return;
        }
        
        //Obere und untere Reihe kopieren
        for (int x = 0; x < width; x++) {
            dst.setRGB(x, 0, src.getRGB(x, 0));//Obere Reihe
            dst.setRGB(x, height - 1, src.getRGB(x, height - 1));//Untere Reihe
        }
        
        // Linke und rechte Spalte kopieren (ohne Ecken, die schon kopiert wurden)
        for (int y = 1; y < height - 1; y++) {
            dst.setRGB(0, y, src.getRGB(0, y));//Linke Spalte
            dst.setRGB(width - 1, y, src.getRGB(width - 1, y));//Rechte Spalte
        }
    }
    private static float colorDifference(int rgb1, int rgb2) {
        int r1 = (rgb1 >> 16) & 0xFF, g1 = (rgb1 >> 8) & 0xFF, b1 = rgb1 & 0xFF;
        int r2 = (rgb2 >> 16) & 0xFF, g2 = (rgb2 >> 8) & 0xFF, b2 = rgb2 & 0xFF;
        
        // Euklidische Distanz
        return (float) Math.sqrt(
            Math.pow(r1 - r2, 2) + 
            Math.pow(g1 - g2, 2) + 
            Math.pow(b1 - b2, 2)
        );
    }
    private static int getShadedColor(Color color, double dist, double maxDist){
            if (dist < 0) return 0;
            //Weiter weg dunkler, näher = heller
            double brightness;
            if (dist >= maxDist) {
                brightness = 0.1; // Sehr dunkel
            } else {
                // Normalisiere Distanz zu 0-1 und invertiere (näher = heller)
                double normalized = 1.0 - Math.pow(dist, 0.7) / Math.pow(maxDist, 0.7);
                // Mindestens etwas Helligkeit behalten
                brightness = 0.1 + normalized * 0.9; // 30%-100% Helligkeit
            }
           // brightness = Math.pow(brightness, 1.55);
            //Farbe mit Helligkeit multiplizieren
            double r = color.getR()/255.0 * brightness;
            double g = color.getG()/255.0 * brightness;
            double b = color.getB()/255.0 * brightness;

            r = linearToSRGB(r);
            g = linearToSRGB(g);
            b = linearToSRGB(b);
            
            return ((int)(r * 255) << 16) | 
                ((int)(g * 255) << 8) | 
                (int)(b * 255);
    }
    private static double linearToSRGB(double linear) {
        if (linear <= 0.0031308) {
            return linear * 12.92;
        } else {
            return 1.055 * Math.pow(linear, 1.0/2.4) - 0.055;
        }
    }
    private static void reallySave(BufferedImage image, String name){
        try {
            ImageIO.write(image, "png", new File(name + ".png"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(name.length() < 7) openImage(name + ".png");
    }
    private static void openImage(String filename) {
        try {
            File file = new File(filename);
            if (file.exists() && Desktop.isDesktopSupported()) {
                Desktop desktop = Desktop.getDesktop();
                if(number > -99) desktop.open(file);
                System.out.println("Bild geöffnet: " + filename);
            } else {
                System.out.println("Kann Bild nicht öffnen: " + filename);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    private static int toGray(double dist, double maxDist){
        if (dist < 0) return 0; // Hintergrund schwarz
        double v = 1.0 - (Math.pow(dist, 0.7) / Math.pow(maxDist, 0.7));
        v = Math.max(0, Math.min(1, v));
       // v = Math.pow(v, 1.5);
        return (int)(v * 255);
    }
}

